
# =================================================================
#  SPOT-QUARTERLY FUTURES SPREAD ARBITRAGE — LIVE TRADER  v1
#  Imports all logic from quarterly_arb.py (no manual calculations)
#  Run: python quarterly_arb_live.py
# =================================================================

import time
import datetime
import hmac
import hashlib
import urllib.parse
import requests

# ── Import all shared logic from backtest script ──────────────────
from quarterly_arb import (
    CONFIG,
    SPOT_URL,
    FUTURES_URL,
    EXCH_URL,
    get_quarterly_contracts,
    fetch_klines,
)

# ── LIVE CONFIG ───────────────────────────────────────────────────
LIVE_CONFIG = {
    # Copy all strategy params from backtest CONFIG
    **CONFIG,

    # Binance API credentials
    "api_key"    : "xeu9pqJqfQWMPxbjdhi5x54XjkxXgpfGuwhASTdGZXXruF6sp7R1GCQ7vopbAwOS",
    "api_secret" : "WW2mxzgt9dN8f2vZ2McsLHpYr2hDfsKzQv1H2YfkGWfqAgY295ksWeLgyxPqrdev",

    # ── FUTURES LEG ──────────────────────────────────────────────
    "leverage"            : 20,       # futures leverage (quarterly contracts: max ~20x for small accounts)

    # ── SPOT MARGIN LEG ──────────────────────────────────────────
    "spot_margin_type"    : "ISOLATED",   # ISOLATED or CROSS
    "spot_leverage"       : 10,           # isolated margin leverage (max depends on asset)

    # How often to scan for opportunities (seconds)
    "scan_interval_sec": 1,

    # Max open position to guard against double-entry
    "max_open_positions": 1,
}

SPOT_ORDER_URL        = "https://api.binance.com/api/v3/order"
SPOT_ACCOUNT_URL      = "https://api.binance.com/api/v3/account"
FUT_ORDER_URL         = "https://fapi.binance.com/fapi/v1/order"
FUT_ACCOUNT_URL       = "https://fapi.binance.com/fapi/v2/account"
FUT_LEVERAGE_URL      = "https://fapi.binance.com/fapi/v1/leverage"
FUT_POSITION_URL      = "https://fapi.binance.com/fapi/v2/positionRisk"
FUT_PRICE_URL         = "https://fapi.binance.com/fapi/v1/ticker/price"
SPOT_PRICE_URL        = "https://api.binance.com/api/v3/ticker/price"
# Margin endpoints
MARGIN_ORDER_URL      = "https://api.binance.com/sapi/v1/margin/order"
MARGIN_ACCOUNT_URL    = "https://api.binance.com/sapi/v1/margin/isolated/account"
MARGIN_PAIR_URL       = "https://api.binance.com/sapi/v1/margin/isolated/pair"
MARGIN_LEVERAGE_URL   = "https://api.binance.com/sapi/v1/margin/isolated/leverage"

# ── SIGNED REQUEST HELPER ─────────────────────────────────────────
def signed_request(method, url, params, cfg):
    params["timestamp"] = int(time.time() * 1000)
    qs  = urllib.parse.urlencode(params)
    sig = hmac.new(cfg["api_secret"].encode(), qs.encode(), hashlib.sha256).hexdigest()
    params["signature"] = sig
    headers = {"X-MBX-APIKEY": cfg["api_key"]}
    if method == "GET":
        r = requests.get(url, params=params, headers=headers, timeout=10)
    elif method == "POST":
        r = requests.post(url, params=params, headers=headers, timeout=10)
    elif method == "DELETE":
        r = requests.delete(url, params=params, headers=headers, timeout=10)
    else:
        raise ValueError("Unknown method: " + method)
    return r.json()


# ── FETCH CURRENT PRICES ──────────────────────────────────────────
def get_spot_price(symbol):
    r = requests.get(SPOT_PRICE_URL, params={"symbol": symbol}, timeout=10)
    return float(r.json()["price"])


def get_fut_price(symbol):
    r = requests.get(FUT_PRICE_URL, params={"symbol": symbol}, timeout=10)
    return float(r.json()["price"])


# ── SET LEVERAGE ──────────────────────────────────────────────────
def set_leverage(fut_symbol, leverage, cfg):
    params = {"symbol": fut_symbol, "leverage": leverage}
    resp = signed_request("POST", FUT_LEVERAGE_URL, params, cfg)
    if "leverage" in resp:
        print(f"[+] Futures leverage set to {resp['leverage']}x for {fut_symbol}")
        if int(resp["leverage"]) < leverage:
            print(f"    [!] Requested {leverage}x but Binance capped to {resp['leverage']}x for this contract/balance")
    elif resp.get("code") == -4028:
        # Binance returns max valid leverage in the msg, e.g. 'Leverage 100 is not valid, max is 20'
        msg = resp.get("msg", "")
        print(f"[!] Futures leverage {leverage}x rejected: {msg}")
        print(f"    Retrying with lower leverage ...")
        # Binary search downward to find max valid leverage
        for try_lev in [50, 25, 20, 10, 5, 2, 1]:
            if try_lev >= leverage:
                continue
            r2 = signed_request("POST", FUT_LEVERAGE_URL, {"symbol": fut_symbol, "leverage": try_lev}, cfg)
            if "leverage" in r2:
                print(f"[+] Futures leverage set to {r2['leverage']}x for {fut_symbol}  (auto-fallback)")
                return r2
        print(f"[!] Could not set any leverage. Check account permissions.")
    else:
        print(f"[!] Leverage set error: {resp}")
    return resp


# ── SETUP SPOT ISOLATED MARGIN ────────────────────────────────────
def setup_spot_isolated_margin(symbol, leverage, cfg):
    """Enable isolated margin pair and set leverage."""
    # Check / enable isolated margin pair
    pair_resp = signed_request("GET", MARGIN_PAIR_URL, {"symbol": symbol}, cfg)
    if pair_resp.get("isMarginTrade") or pair_resp.get("symbol"):
        print(f"[+] Isolated margin pair {symbol} already enabled")
    else:
        print(f"[!] Isolated margin pair info: {pair_resp}")
        print(f"    (Enable the pair manually in Binance Isolated Margin if not yet active)")

    # Set isolated margin leverage
    lev_resp = signed_request("POST", MARGIN_LEVERAGE_URL,
                              {"symbol": symbol, "leverage": leverage}, cfg)
    if "leverage" in lev_resp:
        print(f"[+] Spot isolated margin leverage set to {lev_resp['leverage']}x for {symbol}")
    elif lev_resp.get("status") == 404 or lev_resp.get("code") == -1121:
        print(f"[!] Isolated margin leverage endpoint not available for this account/key.")
        print(f"    Set leverage manually in Binance → Margin → Isolated → {symbol} → Adjust Leverage.")
    else:
        print(f"[!] Margin leverage response: {lev_resp}")
    return lev_resp


# ── DISPLAY BALANCES ──────────────────────────────────────────────
def display_balances(cfg):
    print("\n" + "=" * 58)
    print("  ACCOUNT BALANCES")
    print("=" * 58)

    # --- Spot balances ---
    spot_data = signed_request("GET", SPOT_ACCOUNT_URL, {}, cfg)
    if "balances" not in spot_data:
        print(f"[!] Could not fetch spot balances: {spot_data}")
    else:
        spot_assets = {b["asset"]: float(b["free"]) + float(b["locked"])
                       for b in spot_data["balances"]
                       if float(b["free"]) + float(b["locked"]) > 0.0001}
        print("  [SPOT WALLET]")
        for asset, bal in sorted(spot_assets.items()):
            print(f"    {asset:<10} : {bal:.6f}")

    print()

    # --- Isolated Margin balances ---
    margin_data = signed_request("GET", MARGIN_ACCOUNT_URL, {}, cfg)
    print(f"  [ISOLATED MARGIN WALLET]  leverage={cfg['spot_leverage']}x")
    if "assets" in margin_data:
        active_pairs = []
        for pair in margin_data["assets"]:
            sym        = pair.get("symbol", "?")
            base_free  = float(pair["baseAsset"]["free"])
            base_bor   = float(pair["baseAsset"]["borrowed"])
            quote_free = float(pair["quoteAsset"]["free"])
            quote_bor  = float(pair["quoteAsset"]["borrowed"])
            margin_ratio = pair.get("marginRatio", "N/A")
            total = base_free + base_bor + quote_free + quote_bor
            active_pairs.append((sym, base_free, base_bor, quote_free, quote_bor, margin_ratio, total))
            print(f"    {sym:<12}  BTC={base_free:.6f} (bor={base_bor:.6f})  "
                  f"USDT={quote_free:.2f} (bor={quote_bor:.2f})  ratio={margin_ratio}")
        if not active_pairs:
            print("    (no isolated margin pairs found — transfer funds via Binance Margin to activate)")
    else:
        print(f"    [!] Could not fetch: {margin_data}")

    print()

    # --- Futures balances ---
    fut_data = signed_request("GET", FUT_ACCOUNT_URL, {}, cfg)
    print(f"  [FUTURES WALLET]  leverage={cfg['leverage']}x")
    if "assets" not in fut_data:
        print(f"    [!] Could not fetch: {fut_data}")
    else:
        # Always show main assets (show 0 if empty)
        main_assets = {"USDT", "BNB", "BUSD"}
        all_assets   = {a["asset"]: float(a["walletBalance"]) for a in fut_data["assets"]}
        nonzero      = {k: v for k, v in all_assets.items() if v > 0.0001}
        # Union: nonzero assets + main assets always shown
        show_assets  = {**{k: all_assets.get(k, 0.0) for k in main_assets}, **nonzero}
        for asset, bal in sorted(show_assets.items()):
            print(f"    {asset:<10} : {bal:.6f}")
        total_unrealised = sum(float(a["unrealizedProfit"]) for a in fut_data["assets"])
        print(f"    UnrealizedPnL : ${total_unrealised:.4f}")

    print("=" * 58 + "\n")


# ── PLACE SPOT ISOLATED MARGIN ORDER ─────────────────────────────
def place_spot_order(symbol, side, qty, cfg):
    """Routes through isolated margin endpoint using spot_leverage."""
    params = {
        "symbol"       : symbol,
        "side"         : side,
        "type"         : "MARKET",
        "quantity"     : qty,
        "isIsolated"   : "TRUE",
        "sideEffectType": "MARGIN_BUY",   # auto-borrow if needed
    }
    resp = signed_request("POST", MARGIN_ORDER_URL, params, cfg)
    print(f"  MARGIN-SPOT {side} {qty} {symbol} → orderId={resp.get('orderId', '?')} status={resp.get('status', '?')}")
    if "code" in resp:
        print(f"  [!] Margin spot order error: {resp}")
    return resp


# ── PLACE FUTURES ORDER ───────────────────────────────────────────
def place_futures_order(symbol, side, qty, cfg):
    """side: 'BUY' or 'SELL'.  Uses MARKET + reduceOnly=False by default."""
    params = {
        "symbol"     : symbol,
        "side"       : side,
        "type"       : "MARKET",
        "quantity"   : qty,
        "reduceOnly" : "false",
    }
    resp = signed_request("POST", FUT_ORDER_URL, params, cfg)
    print(f"  FUTURES {side} {qty} {symbol} → orderId={resp.get('orderId', '?')} status={resp.get('status', '?')}")
    if "code" in resp:
        print(f"  [!] Futures order error: {resp}")
    return resp


# ── CLOSE FUTURES ORDER ───────────────────────────────────────────
def close_futures_order(symbol, side, qty, cfg):
    """Close/reduce a futures position."""
    params = {
        "symbol"     : symbol,
        "side"       : side,
        "type"       : "MARKET",
        "quantity"   : qty,
        "reduceOnly" : "true",
    }
    resp = signed_request("POST", FUT_ORDER_URL, params, cfg)
    print(f"  FUTURES CLOSE {side} {qty} {symbol} → orderId={resp.get('orderId', '?')} status={resp.get('status', '?')}")
    if "code" in resp:
        print(f"  [!] Futures close error: {resp}")
    return resp


# ── COMPUTE LIVE SPREAD METRICS ───────────────────────────────────
def compute_spread_metrics(spot_p, fut_p, expiry_dt):
    now   = datetime.datetime.now(datetime.timezone.utc)
    secs  = max((expiry_dt - now).total_seconds(), 60.0)
    dte   = secs / 86400.0

    spread      = fut_p - spot_p
    spread_rate = spread / spot_p
    apr         = spread_rate * 365.0 / dte * 100.0
    return spread, spread_rate, apr, dte


# ── ENTRY SIGNAL (reuses backtest logic verbatim) ─────────────────
def check_entry_signal(spread, apr, dte, spot_p, fut_p, cfg):
    sf       = cfg["spot_fee"]
    ff       = cfg["futures_fee"]
    min_apr  = cfg["min_apr_pct"]
    fee_mult = cfg["fee_safety_mult"]
    min_dte  = cfg["min_dte"]

    sp_entry_on  = cfg["spread_entry_enabled"]
    sp_entry_min = cfg["spread_entry_min_usdt"]
    sp_entry_dte = cfg["spread_entry_min_dte"]

    if dte < min_dte:
        return None, None

    rt_fee = 2.0 * (spot_p * sf + fut_p * ff)          # per-unit, qty-independent

    mode_a = (apr >= min_apr)
    mode_b = (sp_entry_on and abs(spread) >= sp_entry_min and dte >= sp_entry_dte)

    if (mode_a or mode_b) and abs(spread) > rt_fee * fee_mult:
        direction  = "long_spot_short_fut" if spread > 0 else "short_spot_long_fut"
        entry_mode = "APR" if mode_a else "SPREAD"
        return direction, entry_mode

    return None, None


# ── EXIT SIGNAL (reuses backtest logic verbatim) ──────────────────
def check_exit_signal(trade, spread, dte, spot_p, fut_p, bars_held, cfg, expiry_dt):
    sf   = cfg["spot_fee"]
    ff   = cfg["futures_fee"]
    qty  = cfg["quantity"]

    close_before = datetime.timedelta(minutes=cfg["close_before_expiry_mins"])
    now          = datetime.datetime.now(datetime.timezone.utc)
    tte          = expiry_dt - now
    expiry_exit  = tte <= close_before

    if trade["direction"] == "long_spot_short_fut":
        gross = (spot_p - trade["entry_spot"]) * qty + (trade["entry_fut"] - fut_p) * qty
    else:
        gross = (trade["entry_spot"] - spot_p) * qty + (fut_p - trade["entry_fut"]) * qty

    fee_now  = spot_p * qty * sf + fut_p * qty * ff
    live_net = gross - trade["entry_fees"] - fee_now

    if dte >= 30:
        exit_target = abs(trade["entry_spread"]) * (1.0 - cfg["exit_pct_of_entry"])
    else:
        exit_target = cfg["exit_spread_usdt"]

    min_hold = cfg["min_hold_bars"]
    early_exit = (abs(spread) <= exit_target and bars_held >= min_hold and live_net > 0)

    return early_exit or expiry_exit, live_net, "expiry" if expiry_exit else "convergence"


# ── MAIN LOOP ─────────────────────────────────────────────────────
def run_live(cfg):
    print("\n" + "=" * 58)
    print("  SPOT-QUARTERLY FUTURES SPREAD ARB — LIVE TRADER")
    print("  Symbol        : " + cfg["symbol"])
    print("  Quantity      : " + str(cfg["quantity"]) + " BTC")
    print("  Spot Margin   : " + cfg["spot_margin_type"] + "  " + str(cfg["spot_leverage"]) + "x")
    print("  Futures Lev   : " + str(cfg["leverage"]) + "x")
    print("  Scan every    : " + str(cfg["scan_interval_sec"]) + " seconds")
    print("=" * 58)

    # ── 1. Show balances ──────────────────────────────────────────
    display_balances(cfg)

    # ── 2. Discover contract ──────────────────────────────────────
    print("[+] Discovering quarterly contracts ...")
    contracts = get_quarterly_contracts(cfg["symbol"])
    if not contracts:
        print("[!] No quarterly contracts found. Exiting.")
        return
    for idx, c in enumerate(contracts):
        marker = " <-- SELECTED" if idx == cfg["use_contract"] else ""
        print(f"  [{idx}] {c['symbol']}  |  {c['type']}  |  expiry: {c['expiry_dt'].strftime('%Y-%m-%d')}{marker}")

    if cfg["use_contract"] >= len(contracts):
        print("[!] use_contract index out of range.")
        return

    target     = contracts[cfg["use_contract"]]
    fut_symbol = target["symbol"]
    expiry_dt  = target["expiry_dt"]

    print(f"\n[+] Selected: {fut_symbol}  (expires {expiry_dt.strftime('%Y-%m-%d %H:%M UTC')})")

    # ── 3. Set leverage: futures + spot isolated margin ──────────
    set_leverage(fut_symbol, cfg["leverage"], cfg)
    setup_spot_isolated_margin(cfg["symbol"], cfg["spot_leverage"], cfg)

    # ── 4. Fee summary + capital requirements (live prices) ──────
    try:
        _sp  = get_spot_price(cfg["symbol"])
        _fp  = get_fut_price(fut_symbol)
        _qty = cfg["quantity"]
        _sf  = cfg["spot_fee"]
        _ff  = cfg["futures_fee"]

        # ── Fees ──────────────────────────────────────────────────
        _fee_open  = _sp * _qty * _sf + _fp * _qty * _ff
        _fee_close = _sp * _qty * _sf + _fp * _qty * _ff
        _rt_fee    = _fee_open + _fee_close
        _rt_fee_1u = 2.0 * (_sp * _sf + _fp * _ff)   # per-unit, matches backtest gate

        # ── Capital required (margin = notional / leverage) ───────
        _spot_notional = _sp * _qty
        _fut_notional  = _fp * _qty
        _spot_margin   = _spot_notional / cfg["spot_leverage"]    # collateral in spot isolated wallet
        _fut_margin    = _fut_notional  / cfg["leverage"]         # initial margin in futures wallet
        # Add ~10% buffer for price moves / maintenance margin
        _spot_buf = _spot_margin * 1.10
        _fut_buf  = _fut_margin  * 1.10
        _total    = _spot_buf + _fut_buf

        print("\n" + "=" * 58)
        print("  FEE ESTIMATE + CAPITAL REQUIRED  (qty=" + str(_qty) + " BTC)")
        print("=" * 58)
        print(f"  Spot price now         : ${_sp:,.2f}")
        print(f"  Futures price now      : ${_fp:,.2f}")
        print(f"  Notional (spot leg)    : ${_spot_notional:,.2f}  ({_qty} BTC × ${_sp:,.0f})")
        print(f"  Notional (futures leg) : ${_fut_notional:,.2f}  ({_qty} BTC × ${_fp:,.0f})")
        print("-" * 58)
        print(f"  Spot fee rate          : {_sf*100:.4f}%  (BNB taker)")
        print(f"  Futures fee rate       : {_ff*100:.4f}%  (BNB taker)")
        print(f"  Open leg fees          : ${_fee_open:.4f}")
        print(f"  Close leg fees         : ${_fee_close:.4f}")
        print(f"  Round-trip total fees  : ${_rt_fee:.4f}")
        print(f"  Min spread to enter    : ${_rt_fee_1u * cfg['fee_safety_mult']:.4f}/BTC  "
              f"(rt_fee × {cfg['fee_safety_mult']}x safety)")
        print("-" * 58)
        print(f"  [SPOT] Isolated margin {cfg['spot_leverage']}x")
        print(f"    Collateral needed    : ${_spot_margin:.2f}  (= ${_spot_notional:.2f} / {cfg['spot_leverage']}x)")
        print(f"    With 10% buffer      : ${_spot_buf:.2f}  ← transfer to isolated BTCUSDT wallet")
        print(f"  [FUTURES] {cfg['leverage']}x leverage")
        print(f"    Initial margin       : ${_fut_margin:.2f}  (= ${_fut_notional:.2f} / {cfg['leverage']}x)")
        print(f"    With 10% buffer      : ${_fut_buf:.2f}  ← transfer to futures wallet")
        print(f"  Total capital needed   : ${_total:.2f}  (both legs + buffer)")
        print("=" * 58)
    except Exception as _e:
        print(f"[!] Could not compute fee estimate: {_e}")

    # ── 5. Main scan loop ─────────────────────────────────────────
    open_trade = None      # dict or None
    bars_held  = 0
    scan_count = 0

    print("\n[+] Starting live scan loop. Ctrl+C to stop.\n")

    while True:
        scan_count += 1
        now_str = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

        try:
            spot_p = get_spot_price(cfg["symbol"])
            fut_p  = get_fut_price(fut_symbol)
        except Exception as e:
            print(f"[{now_str}]  [!] Price fetch error: {e}")
            time.sleep(cfg["scan_interval_sec"])
            continue

        spread, spread_rate, apr, dte = compute_spread_metrics(spot_p, fut_p, expiry_dt)

        print(f"[{now_str}]  SPOT={spot_p:.2f}  FUT={fut_p:.2f}  "
              f"SPREAD={spread:+.2f}  APR={apr:.2f}%  DTE={dte:.1f}d")

        # ── EXIT check ────────────────────────────────────────────
        if open_trade is not None:
            bars_held += 1
            should_exit, live_net, reason = check_exit_signal(
                open_trade, spread, dte, spot_p, fut_p, bars_held, cfg, expiry_dt
            )

            print(f"  [POSITION]  dir={open_trade['direction']}  "
                  f"entry_spread={open_trade['entry_spread']:+.2f}  "
                  f"live_net=${live_net:.4f}  held={bars_held}bars")

            if should_exit:
                print(f"\n  >>> EXIT triggered  reason={reason}  net=${live_net:.4f}")
                qty = cfg["quantity"]
                if open_trade["direction"] == "long_spot_short_fut":
                    # close spot SELL, close fut BUY
                    place_spot_order(cfg["symbol"], "SELL", qty, cfg)
                    close_futures_order(fut_symbol, "BUY", qty, cfg)
                else:
                    # close spot BUY, close fut SELL
                    place_spot_order(cfg["symbol"], "BUY", qty, cfg)
                    close_futures_order(fut_symbol, "SELL", qty, cfg)

                print(f"  [CLOSED]  exit_spread={spread:.2f}  net_pnl=${live_net:.4f}")
                open_trade  = None
                bars_held   = 0
                print()

        # ── ENTRY check ───────────────────────────────────────────
        elif open_trade is None:
            direction, entry_mode = check_entry_signal(
                spread, apr, dte, spot_p, fut_p, cfg
            )

            if direction is not None:
                qty      = cfg["quantity"]
                sf       = cfg["spot_fee"]
                ff       = cfg["futures_fee"]
                fee_open = spot_p * qty * sf + fut_p * qty * ff

                print(f"\n  >>> ENTRY triggered  dir={direction}  mode={entry_mode}  spread={spread:+.2f}")

                if direction == "long_spot_short_fut":
                    # Buy spot, Short futures
                    place_spot_order(cfg["symbol"], "BUY", qty, cfg)
                    place_futures_order(fut_symbol, "SELL", qty, cfg)
                else:
                    # Sell spot, Long futures
                    place_spot_order(cfg["symbol"], "SELL", qty, cfg)
                    place_futures_order(fut_symbol, "BUY", qty, cfg)

                open_trade = {
                    "direction"   : direction,
                    "entry_mode"  : entry_mode,
                    "entry_spot"  : spot_p,
                    "entry_fut"   : fut_p,
                    "entry_spread": spread,
                    "entry_apr"   : apr,
                    "entry_dte"   : dte,
                    "entry_fees"  : fee_open,
                    "entry_time"  : datetime.datetime.now(datetime.timezone.utc),
                }
                bars_held = 0
                print(f"  [OPEN]  spot={spot_p:.2f}  fut={fut_p:.2f}  "
                      f"spread={spread:+.2f}  apr={apr:.2f}%\n")

        time.sleep(cfg["scan_interval_sec"])


# ── ENTRY POINT ───────────────────────────────────────────────────
if __name__ == "__main__":
    cfg = LIVE_CONFIG

    if cfg["api_key"] == "YOUR_API_KEY":
        print("[!] ERROR: Set your api_key and api_secret in LIVE_CONFIG before running.")
        exit(1)

    try:
        run_live(cfg)
    except KeyboardInterrupt:
        print("\n\n[+] Stopped by user. Goodbye.")
