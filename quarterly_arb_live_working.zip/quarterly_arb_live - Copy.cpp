#include <atomic>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
void enable_vt_mode() {
  HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
  if (hOut == INVALID_HANDLE_VALUE)
    return;
  DWORD dwMode = 0;
  if (!GetConsoleMode(hOut, &dwMode))
    return;
  dwMode |= 0x0004; // ENABLE_VIRTUAL_TERMINAL_PROCESSING
  SetConsoleMode(hOut, dwMode);
}
#else
void enable_vt_mode() {}
#endif

// Dependencies (must be installed via vcpkg/MSYS2/etc)
#include <boost/asio/connect.hpp>
#include <boost/asio/ip/tcp.hpp>
#include <boost/asio/ssl/stream.hpp>
#include <boost/beast/core.hpp>
#include <boost/beast/ssl.hpp>
#include <boost/beast/websocket.hpp>
#include <boost/beast/websocket/ssl.hpp>
#include <curl/curl.h>
#include <nlohmann/json.hpp>
#include <openssl/hmac.h>
#include <openssl/sha.h>

using json = nlohmann::json;
namespace beast = boost::beast;
namespace websocket = beast::websocket;
namespace asio = boost::asio;
namespace ssl = asio::ssl;
using tcp = asio::ip::tcp;

// =========================================================================
// CONFIGURATION
// =========================================================================
struct Config {
  std::string api_key =
      "xeu9pqJqfQWMPxbjdhi5x54XjkxXgpfGuwhASTdGZXXruF6sp7R1GCQ7vopbAwOS";
  std::string api_secret =
      "WW2mxzgt9dN8f2vZ2McsLHpYr2hDfsKzQv1H2YfkGWfqAgY295ksWeLgyxPqrdev";
  std::string symbol = "BTCUSDT";
  double quantity = 0.0001;
  int use_contract = 0;

  double spot_fee = 0.001;
  double futures_fee = 0.00045;

  double min_apr_pct = 8.0;
  bool spread_entry_enabled = true;
  double spread_entry_min_usdt = 110.0;
  double spread_entry_min_dte = 20.0;

  double fee_safety_mult = 1.3;
  double exit_pct_of_entry = 0.20;
  double exit_spread_usdt = 8.0;

  int min_hold_bars = 0;
  int close_before_expiry_mins = 120;
  double min_dte = 1.0;

  int leverage = 20;
  int spot_leverage = 10;
  int max_open_positions = 1;

  double print_interval_sec = 0.01;
  bool dry_run = true;
};

// =========================================================================
// GLOBALS & CONSTANTS
// =========================================================================
const std::string SPOT_URL = "https://api.binance.com/api/v3";
const std::string FUT_URL = "https://fapi.binance.com/fapi/v1";
const std::string SPOT_ORDER_URL = SPOT_URL + "/order";
const std::string MARGIN_ORDER_URL =
    "https://api.binance.com/sapi/v1/margin/order";
const std::string FUT_ORDER_URL = FUT_URL + "/order";

Config cfg;
static size_t WriteCallback(void *contents, size_t size, size_t nmemb,
                            void *userp) {
  ((std::string *)userp)->append((char *)contents, size * nmemb);
  return size * nmemb;
}

// =========================================================================
// HMAC SHA256 & CURL REQUESTS
// =========================================================================
std::string hmac_sha256(const std::string &key, const std::string &data) {
  unsigned char hash[32];
  unsigned int len = 32;
  HMAC_CTX *hmac = HMAC_CTX_new();
  HMAC_Init_ex(hmac, &key[0], key.length(), EVP_sha256(), NULL);
  HMAC_Update(hmac, (unsigned char *)&data[0], data.length());
  HMAC_Final(hmac, hash, &len);
  HMAC_CTX_free(hmac);

  std::stringstream ss;
  for (unsigned int i = 0; i < len; i++) {
    ss << std::hex << std::setw(2) << std::setfill('0') << (int)hash[i];
  }
  return ss.str();
}

long long get_current_ms() {
  return std::chrono::duration_cast<std::chrono::milliseconds>(
             std::chrono::system_clock::now().time_since_epoch())
      .count();
}

json signed_request(const std::string &method, const std::string &url_base,
                    std::string query_string) {
  long long ts = get_current_ms();
  if (!query_string.empty())
    query_string += "&";
  query_string += "timestamp=" + std::to_string(ts);

  std::string signature = hmac_sha256(cfg.api_secret, query_string);
  std::string full_url =
      url_base + "?" + query_string + "&signature=" + signature;

  CURL *curl = curl_easy_init();
  std::string readBuffer;
  if (curl) {
    struct curl_slist *headers = NULL;
    std::string apiKeyHeader = "X-MBX-APIKEY: " + cfg.api_key;
    headers = curl_slist_append(headers, apiKeyHeader.c_str());

    curl_easy_setopt(curl, CURLOPT_URL, full_url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);

    // Bypass strict Windows MSYS2 CA Certificate bundle requirements
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

    if (method == "POST") {
      curl_easy_setopt(curl, CURLOPT_POST, 1L);
      curl_easy_setopt(curl, CURLOPT_POSTFIELDS, "");
    }

    CURLcode res = curl_easy_perform(curl);
    if (res != CURLE_OK && readBuffer.empty()) {
      readBuffer = R"({"error": "cURL failure: )" +
                   std::string(curl_easy_strerror(res)) + R"("})";
    }

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
  }
  try {
    return json::parse(readBuffer);
  } catch (...) {
    return json::parse(
        R"({"parse_error": "failed to parse json", "raw_buffer": ")" +
        readBuffer + R"("})");
  }
}

// =========================================================================
// ACCOUNT BALANCES POLLER
// =========================================================================
std::atomic<double> bal_spot_usdt{0};
std::atomic<double> bal_spot_btc{0};
std::atomic<double> bal_fut_usdt{0};

void balance_updater_thread() {
  while (true) {
    if (!cfg.api_key.empty() && cfg.api_key != "YOUR_API_KEY") {
      json m_res = signed_request(
          "GET", "https://api.binance.com/sapi/v1/margin/isolated/account", "");
      if (m_res.contains("assets")) {
        for (auto &p : m_res["assets"]) {
          if (p.contains("symbol") && p["symbol"] == cfg.symbol) {
            bal_spot_btc = std::stod(p["baseAsset"]["free"].get<std::string>());
            bal_spot_usdt =
                std::stod(p["quoteAsset"]["free"].get<std::string>());
          }
        }
      }
      json f_res =
          signed_request("GET", "https://fapi.binance.com/fapi/v2/account", "");
      if (f_res.contains("assets")) {
        for (auto &a : f_res["assets"]) {
          std::string ast = a["asset"];
          if (ast == "USDT")
            bal_fut_usdt = std::stod(a["availableBalance"].get<std::string>());
        }
      }
    }
    std::this_thread::sleep_for(std::chrono::seconds(15));
  }
}

// =========================================================================
// WEBSOCKET MANAGER
// =========================================================================
class BinanceWebSocketManager {
public:
  std::atomic<double> spot_bid{0.0}, spot_ask{0.0};
  std::atomic<double> fut_bid{0.0}, fut_ask{0.0};
  std::atomic<long long> last_fut_time{0};

  BinanceWebSocketManager(const std::string &s_sym, const std::string &f_sym) {
    spot_symbol = s_sym;
    fut_symbol = f_sym;
    for (char &c : spot_symbol)
      c = std::tolower(c);
    for (char &c : fut_symbol)
      c = std::tolower(c);
  }

  void start() {
    std::thread([this]() {
      run_stream("stream.binance.com", "9443",
                 "/ws/" + spot_symbol + "@bookTicker", true);
    }).detach();
    std::thread([this]() {
      run_stream("fstream.binance.com", "443",
                 "/ws/" + fut_symbol + "@bookTicker", false);
    }).detach();
  }

  double get_spot_price() { return (spot_bid + spot_ask) / 2.0; }
  double get_fut_price() { return (fut_bid + fut_ask) / 2.0; }

private:
  std::string spot_symbol, fut_symbol;

  void run_stream(const std::string &host, const std::string &port,
                  const std::string &target, bool is_spot) {
    try {
      asio::io_context ioc;
      ssl::context ctx{ssl::context::tlsv12_client};

      tcp::resolver resolver{ioc};
      websocket::stream<ssl::stream<tcp::socket>> ws{ioc, ctx};

      auto const results = resolver.resolve(host, port);
      auto ep = asio::connect(ws.next_layer().next_layer(), results);

      if (!SSL_set_tlsext_host_name(ws.next_layer().native_handle(),
                                    host.c_str())) {
        return;
      }

      ws.next_layer().handshake(ssl::stream_base::client);
      ws.set_option(
          websocket::stream_base::decorator([](websocket::request_type &req) {
            req.set(beast::http::field::user_agent, "C++ Binance Bot");
          }));

      ws.handshake(host + ":" + std::to_string(ep.port()), target);
      beast::flat_buffer buffer;
      while (true) {
        ws.read(buffer);
        std::string msg = beast::buffers_to_string(buffer.data());
        buffer.consume(buffer.size());

        auto j = json::parse(msg, nullptr, false);
        if (!j.is_discarded() && j.contains("b") && j.contains("a")) {
          double bid = std::stod(j["b"].get<std::string>());
          double ask = std::stod(j["a"].get<std::string>());
          if (is_spot) {
            spot_bid = bid;
            spot_ask = ask;
          } else {
            fut_bid = bid;
            fut_ask = ask;
            if (j.contains("E"))
              last_fut_time = j["E"].get<long long>();
          }
        }
      }
    } catch (...) {
    }
  }
};

// =========================================================================
// TRADING EXECUTION ENGINE
// =========================================================================
struct SpreadMetrics {
  double spread, spread_rate, apr, dte;
};

struct Trade {
  std::string direction;
  std::string entry_mode;
  double entry_spot;
  double entry_fut;
  double entry_spread;
  double entry_fees;
  int held_bars = 0;
};

SpreadMetrics compute_spread_metrics(double spot_p, double fut_p,
                                     long long expiry_ms) {
  SpreadMetrics m;
  m.spread = fut_p - spot_p;
  m.spread_rate = (m.spread / spot_p) * 100.0;
  double now_sec = get_current_ms() / 1000.0;
  double exp_sec = expiry_ms / 1000.0;
  m.dte = (exp_sec - now_sec) / 86400.0;
  m.apr = (m.dte > 0) ? (m.spread_rate * (365.0 / m.dte)) : 0.0;
  return m;
}

double get_fill_price(const json &resp, double request_qty) {
  if (resp.contains("fills") && resp["fills"].is_array() &&
      !resp["fills"].empty()) {
    double total_qty = 0, total_vol = 0;
    for (auto &f : resp["fills"]) {
      double f_qty = std::stod(f["qty"].get<std::string>());
      double f_px = std::stod(f["price"].get<std::string>());
      total_qty += f_qty;
      total_vol += f_qty * f_px;
    }
    return total_qty > 0 ? (total_vol / total_qty) : 0.0;
  } else if (resp.contains("avgPrice")) {
    return std::stod(resp["avgPrice"].get<std::string>());
  } else if (resp.contains("price")) {
    return std::stod(resp["price"].get<std::string>());
  }
  return 0.0;
}

std::pair<bool, double> place_spot_order(const std::string &side,
                                         const std::string &side_effect,
                                         double price_hint) {
  if (cfg.dry_run)
    return {true, price_hint};
  std::ostringstream qs;
  qs << std::fixed << std::setprecision(5);
  qs << "symbol=" << cfg.symbol << "&side=" << side
     << "&type=MARKET&quantity=" << cfg.quantity
     << "&isIsolated=TRUE&sideEffectType=" << side_effect;
  json resp = signed_request("POST", MARGIN_ORDER_URL, qs.str());
  if (resp.contains("code"))
    return {false, 0.0};
  return {true, get_fill_price(resp, cfg.quantity)};
}

std::pair<bool, double> place_fut_order(const std::string &fut_symbol,
                                        const std::string &side,
                                        bool reduce_only, double price_hint) {
  if (cfg.dry_run)
    return {true, price_hint};
  std::ostringstream qs;
  qs << std::fixed << std::setprecision(5);
  qs << "symbol=" << fut_symbol << "&side=" << side
     << "&type=MARKET&quantity=" << cfg.quantity
     << "&reduceOnly=" << (reduce_only ? "true" : "false");
  json resp = signed_request("POST", FUT_ORDER_URL, qs.str());
  if (resp.contains("code"))
    return {false, 0.0};
  double fill = get_fill_price(resp, cfg.quantity);
  if (fill == 0.0 && resp.contains("orderId")) {
    std::this_thread::sleep_for(std::chrono::milliseconds(150));
    json q_resp = signed_request("GET", FUT_ORDER_URL,
                                 "symbol=" + fut_symbol +
                                     "&orderId=" + resp["orderId"].dump());
    fill = get_fill_price(q_resp, cfg.quantity);
  }
  return {true, fill};
}

// =========================================================================
// UI HELPERS
// =========================================================================
std::string get_time_fmt() {
  auto now = std::chrono::system_clock::now();
  auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                now.time_since_epoch()) %
            1000;
  auto timer = std::chrono::system_clock::to_time_t(now);
  std::tm bt = *std::localtime(&timer);
  std::ostringstream oss;
  oss << std::put_time(&bt, "%H:%M:%S") << '.' << std::setfill('0')
      << std::setw(3) << ms.count();
  return oss.str();
}

void load_config() {
  std::ifstream f("config.json");
  if (!f.is_open())
    f.open("../config.json");
  if (f.is_open()) {
    try {
      json j = json::parse(f);
      if (j.contains("api_key"))
        cfg.api_key = j["api_key"];
      if (j.contains("api_secret"))
        cfg.api_secret = j["api_secret"];
      if (j.contains("symbol"))
        cfg.symbol = j["symbol"];
      if (j.contains("quantity"))
        cfg.quantity = j["quantity"];
      if (j.contains("print_interval_sec"))
        cfg.print_interval_sec = j["print_interval_sec"];
      if (j.contains("dry_run"))
        cfg.dry_run = j["dry_run"];
      if (j.contains("min_apr_pct"))
        cfg.min_apr_pct = j["min_apr_pct"];
      if (j.contains("spot_fee"))
        cfg.spot_fee = j["spot_fee"];
      if (j.contains("futures_fee"))
        cfg.futures_fee = j["futures_fee"];
    } catch (...) {
    }
  }
}

void draw_dashboard(double spot_p, double fut_p, const SpreadMetrics &m,
                    long long ping, int trades, double pnl, bool active,
                    const Trade &t, const std::string &fut_symbol) {
  std::ostringstream out;
  out << "\033[s"; // Save cursor
  out << "\033[H"; // Move to top-left

  out << "\033[1;36m==========================================================="
         "=====================================\033[0m\n";
  out << "  \033[1;37m[ QUANTITATIVE ARBITRAGE ENGINE ]\033[0m        MODE: "
      << (cfg.dry_run ? "\033[1;33mPAPER (DRY RUN)\033[0m "
                      : "\033[1;31mLIVE (DANGER!)\033[0m ")
      << "  STATUS: \033[1;32mLIVE\033[0m\033[K\n";
  out << "\033[1;36m==========================================================="
         "=====================================\033[0m\n";

  std::string base_coin = cfg.symbol.length() > 3
                              ? cfg.symbol.substr(0, cfg.symbol.length() - 4)
                              : "BTC";

  out << "  PAIR        : " << std::left << std::setw(32)
      << (cfg.symbol + " | " + fut_symbol) << "  PING  : " << ping
      << "ms\033[K\n";
  out << "  VOLUME      : " << cfg.quantity << " " << std::left << std::setw(25)
      << base_coin << "  DTE   : " << std::fixed << std::setprecision(1)
      << m.dte << " Days\033[K\n";
  out << "\033[1;30m-----------------------------------------------------------"
         "-------------------------------------\033[0m\n";

  out << "  \033[1;33m[ LIVE MARKET MATRIX ]\033[0m                            "
         "\033[1;36m[ OPEN POSITION ]\033[0m\033[K\n";
  out << "  SPOT        : $" << std::left << std::setw(32) << std::fixed
      << std::setprecision(2) << spot_p << "DIRECTION   : ";
  if (active)
    out << t.direction << "\033[K\n";
  else
    out << "\033[1;30mNONE\033[0m\033[K\n";

  out << "  FUTURES     : $" << std::left << std::setw(32) << fut_p
      << "ENTRY SVD   : ";
  if (active)
    out << std::showpos << t.entry_spread << std::noshowpos << "\033[K\n";
  else
    out << "$0.00\033[K\n";

  double live_net = 0;
  if (active) {
    double gross = (t.direction == "long_spot_short_fut")
                       ? ((spot_p - t.entry_spot) * cfg.quantity +
                          (t.entry_fut - fut_p) * cfg.quantity)
                       : ((t.entry_spot - spot_p) * cfg.quantity +
                          (fut_p - t.entry_fut) * cfg.quantity);
    double fee_now = spot_p * cfg.quantity * cfg.spot_fee +
                     fut_p * cfg.quantity * cfg.futures_fee;
    live_net = gross - t.entry_fees - fee_now;
  }

  out << "  SPREAD      : " << (m.spread > 0 ? "\033[1;32m+" : "\033[1;31m")
      << "$" << std::setprecision(2) << m.spread << "\033[0m";
  out << std::string(34 - std::to_string(m.spread).length(), ' ')
      << "ACTUAL PNL  : ";
  if (active)
    out << (live_net > 0 ? "\033[1;32m+" : "\033[1;31m") << "$" << live_net
        << "\033[0m\033[K\n";
  else
    out << "$0.00\033[K\n";

  out << "  APR YIELD   : "
      << (m.apr >= cfg.min_apr_pct ? "\033[1;32m" : "\033[1;37m") << m.apr
      << "%\033[0m";
  out << std::string(34 - std::to_string(m.apr).length(), ' ')
      << "HOLD BARS   : " << (active ? t.held_bars : 0) << "\033[K\n";

  out << "\033[1;30m-----------------------------------------------------------"
         "-------------------------------------\033[0m\n";
  out << "  \033[1;35m[ ACCOUNT & RISK METRICS ]\033[0m                        "
         "\033[1;35m[ SESSION TOTALS ]\033[0m\033[K\n";

  out << "  USDT        : S: " << std::fixed << std::setprecision(2)
      << bal_spot_usdt.load() << " | F: " << std::left << std::setw(12)
      << bal_fut_usdt.load() << "      TOTAL PNL   : "
      << (pnl > 0 ? "\033[1;32m+" : (pnl < 0 ? "\033[1;31m" : "\033[1;37m"))
      << "$" << pnl << "\033[0m\033[K\n";

  out << "  " << std::left << std::setw(12) << base_coin
      << ": S: " << std::fixed << std::setprecision(5) << std::left
      << std::setw(21) << bal_spot_btc.load()
      << "       TRADES      : " << trades << " Completed\033[K\n";

  double cap_s = (spot_p * cfg.quantity) / cfg.spot_leverage;
  double cap_f = (fut_p * cfg.quantity) / cfg.leverage;
  double rnd_fee = 2.0 * (spot_p * cfg.quantity * cfg.spot_fee +
                          fut_p * cfg.quantity * cfg.futures_fee);

  out << "  MARGIN RQ   : $" << std::fixed << std::setprecision(2) << cap_s
      << " (S) + $" << std::left << std::setw(11) << cap_f << "(F)"
      << " ROUND FEES  : $" << std::fixed << std::setprecision(3) << rnd_fee
      << "\033[K\n";

  out << "\033[1;36m==========================================================="
         "=====================================\033[0m\n";

  out << "\033[u"; // Restore cursor
  std::cout << out.str() << std::flush;
}

void display_boot_summary() {
  if (cfg.api_key == "YOUR_API_KEY")
    return;
  std::cout << "==========================================================\n";
  std::cout << "  ACCOUNT BALANCES\n";
  std::cout << "==========================================================\n";

  json spot_data =
      signed_request("GET", "https://api.binance.com/api/v3/account", "");
  std::cout << "  [SPOT WALLET]\n";
  if (spot_data.contains("balances")) {
    for (auto &b : spot_data["balances"]) {
      double free = std::stod(b["free"].get<std::string>());
      double locked = std::stod(b["locked"].get<std::string>());
      if (free + locked > 0.0001) {
        std::cout << "    " << std::left << std::setw(10)
                  << b["asset"].get<std::string>() << " : " << std::fixed
                  << std::setprecision(6) << (free + locked) << "\n";
      }
    }
  } else {
    std::cout << "    [!] Spot API Error: " << spot_data.dump() << "\n";
  }

  std::cout << "\n  [ISOLATED MARGIN WALLET]  leverage=" << cfg.spot_leverage
            << "x\n";
  json margin_data = signed_request(
      "GET", "https://api.binance.com/sapi/v1/margin/isolated/account", "");
  if (margin_data.contains("assets")) {
    for (auto &p : margin_data["assets"]) {
      std::string sym = p["symbol"];
      double b_free = std::stod(p["baseAsset"]["free"].get<std::string>());
      double b_bor = std::stod(p["baseAsset"]["borrowed"].get<std::string>());
      double q_free = std::stod(p["quoteAsset"]["free"].get<std::string>());
      double q_bor = std::stod(p["quoteAsset"]["borrowed"].get<std::string>());
      std::string ratio = p.contains("marginRatio")
                              ? p["marginRatio"].get<std::string>()
                              : "N/A";

      std::cout << "    " << std::left << std::setw(12) << sym
                << "  BTC=" << std::fixed << std::setprecision(6) << b_free
                << " (bor=" << b_bor << ")  "
                << "USDT=" << std::setprecision(2) << q_free
                << " (bor=" << q_bor << ")  ratio=" << ratio << "\n";

      if (sym == cfg.symbol) {
        bal_spot_btc = b_free;
        bal_spot_usdt = q_free;
      }
    }
  } else {
    std::cout << "    [!] Margin API Error: " << margin_data.dump() << "\n";
  }

  std::cout << "\n  [FUTURES WALLET]  leverage=" << cfg.leverage << "x\n";
  json fut_data =
      signed_request("GET", "https://fapi.binance.com/fapi/v2/account", "");
  if (fut_data.contains("assets")) {
    double unpnl = 0;
    for (auto &a : fut_data["assets"]) {
      double bal = std::stod(a["walletBalance"].get<std::string>());
      unpnl += std::stod(a["unrealizedProfit"].get<std::string>());
      std::string ast = a["asset"];
      if (bal > 0.0001 || ast == "USDT" || ast == "BNB" || ast == "BUSD") {
        std::cout << "    " << std::left << std::setw(10) << ast << " : "
                  << std::fixed << std::setprecision(6) << bal << "\n";
      }
      if (ast == "USDT")
        bal_fut_usdt = bal;
    }
    std::cout << "    UnrealizedPnL : $" << std::fixed << std::setprecision(4)
              << unpnl << "\n";
  } else {
    std::cout << "    [!] Futures API Error: " << fut_data.dump() << "\n";
  }
  std::cout << "==========================================================\n\n";

  std::cout << "Fetching live prices for Fee & Capital Estimate...\n";
  json sp_res = signed_request(
      "GET", "https://api.binance.com/api/v3/ticker/price?symbol=" + cfg.symbol,
      "");
  json fp_res = signed_request(
      "GET",
      "https://fapi.binance.com/fapi/v1/ticker/price?symbol=BTCUSDT_260327",
      "");

  double sp_price = 0, fp_price = 0;
  if (sp_res.contains("price"))
    sp_price = std::stod(sp_res["price"].get<std::string>());
  if (fp_res.contains("price"))
    fp_price = std::stod(fp_res["price"].get<std::string>());

  if (sp_price > 0 && fp_price > 0) {
    double spot_not = sp_price * cfg.quantity;
    double fut_not = fp_price * cfg.quantity;
    double rnd_fee =
        2.0 * (spot_not * cfg.spot_fee + fut_not * cfg.futures_fee);
    double cap_s = spot_not / cfg.spot_leverage;
    double cap_f = fut_not / cfg.leverage;

    std::cout << "==========================================================\n";
    std::cout << "  FEE ESTIMATE + CAPITAL REQUIRED  (qty=" << cfg.quantity
              << " " << cfg.symbol.substr(0, 3) << ")\n";
    std::cout << "==========================================================\n";
    std::cout << "  Spot price now         : $" << std::fixed
              << std::setprecision(2) << sp_price << "\n";
    std::cout << "  Futures price now      : $" << std::fixed
              << std::setprecision(2) << fp_price << "\n";
    std::cout << "  Notional (spot leg)    : $" << spot_not << "  ("
              << cfg.quantity << " " << cfg.symbol.substr(0, 3) << " x $"
              << sp_price << ")\n";
    std::cout << "  Notional (futures leg) : $" << fut_not << "  ("
              << cfg.quantity << " " << cfg.symbol.substr(0, 3) << " x $"
              << fp_price << ")\n";
    std::cout << "  Est. round-trip fees   : $" << std::fixed
              << std::setprecision(4) << rnd_fee << "\n";
    std::cout << "  Est. spot margin req.  : $" << std::fixed
              << std::setprecision(2) << cap_s << " (buffered: $"
              << (cap_s * 1.1) << ")\n";
    std::cout << "  Est. futures margin req.: $" << std::fixed
              << std::setprecision(2) << cap_f << " (buffered: $"
              << (cap_f * 1.1) << ")\n";
    std::cout << "  TOTAL CAPITAL REQUIRED : $" << std::fixed
              << std::setprecision(2) << (cap_s * 1.1 + cap_f * 1.1) << "\n";
    std::cout
        << "==========================================================\n\n";
  }

  std::cout
      << "[+] Boot checks complete. Launching Live Matrix in 5 seconds...\n";
  std::this_thread::sleep_for(std::chrono::seconds(5));
}

int main() {
  enable_vt_mode();
  load_config();
  display_boot_summary();

  std::cout << "\033[2J";    // Clear entire screen on boot
  std::cout << "\033[20;r";  // Lock top 19 rows, make bottom scroll dynamically
  std::cout << "\033[20;1H"; // Move cursor instantly into scroll zone

  std::thread(balance_updater_thread).detach();

  std::string fut_symbol = "BTCUSDT_260327";
  long long expiry_ms = 1774598400000;

  BinanceWebSocketManager ws_manager(cfg.symbol, fut_symbol);
  ws_manager.start();

  while (ws_manager.get_spot_price() == 0.0 ||
         ws_manager.get_fut_price() == 0.0) {
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
  }

  std::cout << "  \033[1;30m[" << get_time_fmt()
            << "]\033[0m \033[1;36m[SYSTEM]\033[0m Dashboard & Execution "
               "Matrix Active.\n";

  long long last_print = 0;
  long long last_log = 0;
  bool active_trade = false;
  Trade current_trade;

  int session_trades = 0;
  double session_pnl = 0.0;

  while (true) {
    double spot_p = ws_manager.get_spot_price();
    double fut_p = ws_manager.get_fut_price();
    if (spot_p == 0.0 || fut_p == 0.0)
      continue;

    SpreadMetrics m = compute_spread_metrics(spot_p, fut_p, expiry_ms);
    long long now = get_current_ms();

    if (now - last_print > cfg.print_interval_sec * 1000) {
      long long ping = now - ws_manager.last_fut_time;
      if (ws_manager.last_fut_time == 0 || ping < 0 || ping > 9999)
        ping = 0;

      draw_dashboard(spot_p, fut_p, m, ping, session_trades, session_pnl,
                     active_trade, current_trade, fut_symbol);
      last_print = now;
    }

    if (now - last_log > 2000) {
      std::cout << "  \033[1;30m[" << get_time_fmt()
                << "]\033[0m TICK S: " << spot_p << " | F: " << fut_p
                << " | SVD: " << std::showpos << m.spread << std::noshowpos
                << "\n";
      last_log = now;
    }

    // ── ENTRY LOGIC ──
    if (!active_trade) {
      double rt_fee = 2.0 * (spot_p * cfg.spot_fee + fut_p * cfg.futures_fee);
      bool mode_a = (m.apr >= cfg.min_apr_pct);
      bool mode_b = (cfg.spread_entry_enabled &&
                     std::abs(m.spread) >= cfg.spread_entry_min_usdt &&
                     m.dte >= cfg.spread_entry_min_dte);

      if ((mode_a || mode_b) &&
          std::abs(m.spread) > rt_fee * cfg.fee_safety_mult) {
        std::cout << "  \033[1;30m[" << get_time_fmt()
                  << "]\033[0m \033[1;33m[ENTRY SIGNAL]\033[0m Locking "
                  << ((m.spread > 0) ? "long_spot_short_fut"
                                     : "short_spot_long_fut")
                  << " (Spread: " << m.spread
                  << ") -> Executing via Rest API...\n";
        std::string dir =
            (m.spread > 0) ? "long_spot_short_fut" : "short_spot_long_fut";

        long long t1 = get_current_ms();
        auto sp_res = place_spot_order(
            (m.spread > 0) ? "BUY" : "SELL",
            (m.spread > 0) ? "MARGIN_BUY" : "AUTO_REPAY", spot_p);
        long long t2 = get_current_ms();
        auto ft_res = place_fut_order(
            fut_symbol, (m.spread > 0) ? "SELL" : "BUY", false, fut_p);
        long long t3 = get_current_ms();

        current_trade.direction = dir;
        current_trade.entry_mode = mode_a ? "APR" : "SPREAD";
        current_trade.entry_spot = sp_res.second;
        current_trade.entry_fut = ft_res.second;
        current_trade.entry_spread = ft_res.second - sp_res.second;
        current_trade.entry_fees =
            (sp_res.second * cfg.quantity * cfg.spot_fee) +
            (ft_res.second * cfg.quantity * cfg.futures_fee);
        current_trade.held_bars = 0;

        if (!sp_res.first || !ft_res.first || sp_res.second <= 0.0 || ft_res.second <= 0.0) {
          std::cout << "  \033[1;30m[" << get_time_fmt()
                    << "]\033[0m \033[1;31m[FAILED]\033[0m Entry order failed/rejected. Spot OK: "
                    << (sp_res.first ? "Y" : "N") << " (" << sp_res.second << ") Fut OK: "
                    << (ft_res.first ? "Y" : "N") << " (" << ft_res.second << ")\n\n";
          // We do NOT set active_trade = true because it failed!
        } else {
          active_trade = true;

          std::cout << "  \033[1;30m[" << get_time_fmt()
                    << "]\033[0m \033[1;32m[SUCCESS]\033[0m Filled SPOT @ "
                    << current_trade.entry_spot << " (" << (t2 - t1)
                    << "ms) FUT @ " << current_trade.entry_fut << " ("
                    << (t3 - t2) << "ms)\n\n";
        }
      }
    }
    // ── EXIT LOGIC ──
    else {
      current_trade.held_bars++;
      double gross = (current_trade.direction == "long_spot_short_fut")
                         ? ((spot_p - current_trade.entry_spot) * cfg.quantity +
                            (current_trade.entry_fut - fut_p) * cfg.quantity)
                         : ((current_trade.entry_spot - spot_p) * cfg.quantity +
                            (fut_p - current_trade.entry_fut) * cfg.quantity);

      double fee_now = spot_p * cfg.quantity * cfg.spot_fee +
                       fut_p * cfg.quantity * cfg.futures_fee;
      double live_net = gross - current_trade.entry_fees - fee_now;

      double exit_target = (m.dte >= 30)
                               ? (std::abs(current_trade.entry_spread) *
                                  (1.0 - cfg.exit_pct_of_entry))
                               : cfg.exit_spread_usdt;

      if (std::abs(m.spread) <= exit_target &&
          current_trade.held_bars >= cfg.min_hold_bars && live_net > 0) {
        std::cout << "  \033[1;30m[" << get_time_fmt()
                  << "]\033[0m \033[1;33m[EXIT SIGNAL]\033[0m Convergence "
                     "Achieved! Dumping positions to secure profit.\n";

        long long t1 = get_current_ms();
        auto sp_res = place_spot_order(
            (current_trade.direction == "long_spot_short_fut") ? "SELL" : "BUY",
            (current_trade.direction == "long_spot_short_fut") ? "AUTO_REPAY"
                                                               : "MARGIN_BUY",
            spot_p);
        long long t2 = get_current_ms();
        auto ft_res = place_fut_order(
            fut_symbol,
            (current_trade.direction == "long_spot_short_fut") ? "BUY" : "SELL",
            true, fut_p);
        long long t3 = get_current_ms();

        double final_gross =
            (current_trade.direction == "long_spot_short_fut")
                ? ((sp_res.second - current_trade.entry_spot) * cfg.quantity +
                   (current_trade.entry_fut - ft_res.second) * cfg.quantity)
                : ((current_trade.entry_spot - sp_res.second) * cfg.quantity +
                   (ft_res.second - current_trade.entry_fut) * cfg.quantity);

        double final_fees = sp_res.second * cfg.quantity * cfg.spot_fee +
                            ft_res.second * cfg.quantity * cfg.futures_fee;
        double actual_net = final_gross - current_trade.entry_fees - final_fees;

        session_trades++;
        session_pnl += actual_net;

        std::cout << "  \033[1;30m[" << get_time_fmt()
                  << "]\033[0m \033[1;32m[SUCCESS]\033[0m Exited SPOT @ "
                  << sp_res.second << " (" << (t2 - t1) << "ms) FUT @ "
                  << ft_res.second << " (" << (t3 - t2)
                  << "ms) | \033[1;32mPNL: $" << actual_net << "\033[0m\n\n";

        active_trade = false;
      }
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }
  return 0;
}
