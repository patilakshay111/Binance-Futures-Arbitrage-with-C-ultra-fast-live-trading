
# =================================================================
#  SPOT-QUARTERLY FUTURES SPREAD ARBITRAGE — LIVE TRADER  v1
#  Imports all logic from quarterly_arb.py (no manual calculations)
#  Run: python quarterly_arb_live.py
# =================================================================

import time
import datetime
import hmac
import hashlib
import urllib.parse
import requests
import json
import threading
import websocket


# ── WEBSOCKET MANAGER FOR ULTRA-LOW LATENCY PRICES ───────────────
class BinanceWebSocketManager:
    def __init__(self, spot_symbol, fut_symbol):
        self.spot_symbol = spot_symbol.upper()
        self.fut_symbol = fut_symbol.upper()
        self.prices = {
            "spot_bid": 0.0, "spot_ask": 0.0,
            "fut_bid": 0.0, "fut_ask": 0.0,
        }
        self.spot_ws = None
        self.fut_ws  = None
        self.stop_event = threading.Event()
        
    def _on_spot_message(self, ws, message):
        data = json.loads(message)
        if 'b' in data and 'a' in data:
            self.prices["spot_bid"] = float(data['b'])
            self.prices["spot_ask"] = float(data['a'])

    def _on_fut_message(self, ws, message):
        data = json.loads(message)
        if 'b' in data and 'a' in data:
            self.prices["fut_bid"] = float(data['b'])
            self.prices["fut_ask"] = float(data['a'])

    def _on_error(self, ws, error):
        pass

    def _start_spot(self):
        url = f"wss://stream.binance.com:9443/ws/{self.spot_symbol.lower()}@bookTicker"
        self.spot_ws = websocket.WebSocketApp(url, on_message=self._on_spot_message, on_error=self._on_error)
        self.spot_ws.run_forever()

    def _start_fut(self):
        url = f"wss://fstream.binance.com/ws/{self.fut_symbol.lower()}@bookTicker"
        self.fut_ws = websocket.WebSocketApp(url, on_message=self._on_fut_message, on_error=self._on_error)
        self.fut_ws.run_forever()

    def start(self):
        t1 = threading.Thread(target=self._start_spot, daemon=True)
        t2 = threading.Thread(target=self._start_fut, daemon=True)
        t1.start()
        t2.start()

    def get_spot_price(self):
        # We use mid-price or just ask/bid depending on needs. Mid-price used for display.
        if self.prices["spot_bid"] == 0:
            return 0.0
        return (self.prices["spot_bid"] + self.prices["spot_ask"]) / 2.0

    def get_fut_price(self):
        if self.prices["fut_bid"] == 0:
            return 0.0
        return (self.prices["fut_bid"] + self.prices["fut_ask"]) / 2.0
        
    def stop(self):
        self.stop_event.set()
        if self.spot_ws: self.spot_ws.close()
        if self.fut_ws:  self.fut_ws.close()

# ── Import all shared logic from backtest script ──────────────────
from quarterly_arb import (
    CONFIG,
    SPOT_URL,
    FUTURES_URL,
    EXCH_URL,
    get_quarterly_contracts,
    fetch_klines,
)

# ── LIVE CONFIG ───────────────────────────────────────────────────
LIVE_CONFIG = {
    # Copy all strategy params from backtest CONFIG
    **CONFIG,

    # Binance API credentials
    "api_key"    : "xeu9pqJqfQWMPxbjdhi5x54XjkxXgpfGuwhASTdGZXXruF6sp7R1GCQ7vopbAwOS",
    "api_secret" : "WW2mxzgt9dN8f2vZ2McsLHpYr2hDfsKzQv1H2YfkGWfqAgY295ksWeLgyxPqrdev",

    # ── FUTURES LEG ──────────────────────────────────────────────
    "leverage"            : 20,       # futures leverage (quarterly contracts: max ~20x for small accounts)

    # ── SPOT MARGIN LEG ──────────────────────────────────────────
    "spot_margin_type"    : "ISOLATED",   # ISOLATED or CROSS
    "spot_leverage"       : 10,           # isolated margin leverage (max depends on asset)

    # Scan speed in milliseconds (200ms = 5 ticks/second)
    "scan_interval_ms"    : 20,

    # Max open position to guard against double-entry
    "max_open_positions": 1,
}

SPOT_ORDER_URL        = "https://api.binance.com/api/v3/order"
SPOT_ACCOUNT_URL      = "https://api.binance.com/api/v3/account"
FUT_ORDER_URL         = "https://fapi.binance.com/fapi/v1/order"
FUT_ACCOUNT_URL       = "https://fapi.binance.com/fapi/v2/account"
FUT_LEVERAGE_URL      = "https://fapi.binance.com/fapi/v1/leverage"
FUT_POSITION_URL      = "https://fapi.binance.com/fapi/v2/positionRisk"
FUT_PRICE_URL         = "https://fapi.binance.com/fapi/v1/ticker/price"
SPOT_PRICE_URL        = "https://api.binance.com/api/v3/ticker/price"
# Margin endpoints
MARGIN_ORDER_URL      = "https://api.binance.com/sapi/v1/margin/order"
MARGIN_ACCOUNT_URL    = "https://api.binance.com/sapi/v1/margin/isolated/account"
MARGIN_PAIR_URL       = "https://api.binance.com/sapi/v1/margin/isolated/pair"
MARGIN_LEVERAGE_URL   = "https://api.binance.com/sapi/v1/margin/isolated/leverage"

# ── SIGNED REQUEST HELPER ─────────────────────────────────────────
def signed_request(method, url, params, cfg):
    params["timestamp"] = int(time.time() * 1000)
    qs  = urllib.parse.urlencode(params)
    sig = hmac.new(cfg["api_secret"].encode(), qs.encode(), hashlib.sha256).hexdigest()
    params["signature"] = sig
    headers = {"X-MBX-APIKEY": cfg["api_key"]}
    if method == "GET":
        r = requests.get(url, params=params, headers=headers, timeout=10)
    elif method == "POST":
        r = requests.post(url, params=params, headers=headers, timeout=10)
    elif method == "DELETE":
        r = requests.delete(url, params=params, headers=headers, timeout=10)
    else:
        raise ValueError("Unknown method: " + method)
    return r.json()


# ── FETCH CURRENT PRICES ──────────────────────────────────────────
def get_spot_price(symbol):
    r = requests.get(SPOT_PRICE_URL, params={"symbol": symbol}, timeout=10)
    return float(r.json()["price"])


def get_fut_price(symbol):
    r = requests.get(FUT_PRICE_URL, params={"symbol": symbol}, timeout=10)
    return float(r.json()["price"])


# ── SET LEVERAGE ──────────────────────────────────────────────────
def set_leverage(fut_symbol, leverage, cfg):
    params = {"symbol": fut_symbol, "leverage": leverage}
    resp = signed_request("POST", FUT_LEVERAGE_URL, params, cfg)
    if "leverage" in resp:
        print(f"[+] Futures leverage set to {resp['leverage']}x for {fut_symbol}")
        if int(resp["leverage"]) < leverage:
            print(f"    [!] Requested {leverage}x but Binance capped to {resp['leverage']}x for this contract/balance")
    elif resp.get("code") == -4028:
        # Binance returns max valid leverage in the msg, e.g. 'Leverage 100 is not valid, max is 20'
        msg = resp.get("msg", "")
        print(f"[!] Futures leverage {leverage}x rejected: {msg}")
        print(f"    Retrying with lower leverage ...")
        # Binary search downward to find max valid leverage
        for try_lev in [50, 25, 20, 10, 5, 2, 1]:
            if try_lev >= leverage:
                continue
            r2 = signed_request("POST", FUT_LEVERAGE_URL, {"symbol": fut_symbol, "leverage": try_lev}, cfg)
            if "leverage" in r2:
                print(f"[+] Futures leverage set to {r2['leverage']}x for {fut_symbol}  (auto-fallback)")
                return r2
        print(f"[!] Could not set any leverage. Check account permissions.")
    else:
        print(f"[!] Leverage set error: {resp}")
    return resp


# ── SETUP SPOT ISOLATED MARGIN ────────────────────────────────────
def setup_spot_isolated_margin(symbol, leverage, cfg):
    """Enable isolated margin pair and set leverage."""
    # Check / enable isolated margin pair
    pair_resp = signed_request("GET", MARGIN_PAIR_URL, {"symbol": symbol}, cfg)
    if pair_resp.get("isMarginTrade") or pair_resp.get("symbol"):
        print(f"[+] Isolated margin pair {symbol} already enabled")
    else:
        print(f"[!] Isolated margin pair info: {pair_resp}")
        print(f"    (Enable the pair manually in Binance Isolated Margin if not yet active)")

    # Set isolated margin leverage
    lev_resp = signed_request("POST", MARGIN_LEVERAGE_URL,
                              {"symbol": symbol, "leverage": leverage}, cfg)
    if "leverage" in lev_resp:
        print(f"[+] Spot isolated margin leverage set to {lev_resp['leverage']}x for {symbol}")
    elif lev_resp.get("status") == 404 or lev_resp.get("code") == -1121:
        print(f"[!] Isolated margin leverage endpoint not available for this account/key.")
        print(f"    Set leverage manually in Binance → Margin → Isolated → {symbol} → Adjust Leverage.")
    else:
        print(f"[!] Margin leverage response: {lev_resp}")
    return lev_resp


# ── DISPLAY BALANCES ──────────────────────────────────────────────
def display_balances(cfg):
    print("\n" + "=" * 58)
    print("  ACCOUNT BALANCES")
    print("=" * 58)

    # --- Spot balances ---
    spot_data = signed_request("GET", SPOT_ACCOUNT_URL, {}, cfg)
    if "balances" not in spot_data:
        print(f"[!] Could not fetch spot balances: {spot_data}")
    else:
        spot_assets = {b["asset"]: float(b["free"]) + float(b["locked"])
                       for b in spot_data["balances"]
                       if float(b["free"]) + float(b["locked"]) > 0.0001}
        print("  [SPOT WALLET]")
        for asset, bal in sorted(spot_assets.items()):
            print(f"    {asset:<10} : {bal:.6f}")

    print()

    # --- Isolated Margin balances ---
    margin_data = signed_request("GET", MARGIN_ACCOUNT_URL, {}, cfg)
    print(f"  [ISOLATED MARGIN WALLET]  leverage={cfg['spot_leverage']}x")
    if "assets" in margin_data:
        active_pairs = []
        for pair in margin_data["assets"]:
            sym        = pair.get("symbol", "?")
            base_free  = float(pair["baseAsset"]["free"])
            base_bor   = float(pair["baseAsset"]["borrowed"])
            quote_free = float(pair["quoteAsset"]["free"])
            quote_bor  = float(pair["quoteAsset"]["borrowed"])
            margin_ratio = pair.get("marginRatio", "N/A")
            total = base_free + base_bor + quote_free + quote_bor
            active_pairs.append((sym, base_free, base_bor, quote_free, quote_bor, margin_ratio, total))
            print(f"    {sym:<12}  BTC={base_free:.6f} (bor={base_bor:.6f})  "
                  f"USDT={quote_free:.2f} (bor={quote_bor:.2f})  ratio={margin_ratio}")
        if not active_pairs:
            print("    (no isolated margin pairs found — transfer funds via Binance Margin to activate)")
    else:
        print(f"    [!] Could not fetch: {margin_data}")

    print()

    # --- Futures balances ---
    fut_data = signed_request("GET", FUT_ACCOUNT_URL, {}, cfg)
    print(f"  [FUTURES WALLET]  leverage={cfg['leverage']}x")
    if "assets" not in fut_data:
        print(f"    [!] Could not fetch: {fut_data}")
    else:
        # Always show main assets (show 0 if empty)
        main_assets = {"USDT", "BNB", "BUSD"}
        all_assets   = {a["asset"]: float(a["walletBalance"]) for a in fut_data["assets"]}
        nonzero      = {k: v for k, v in all_assets.items() if v > 0.0001}
        # Union: nonzero assets + main assets always shown
        show_assets  = {**{k: all_assets.get(k, 0.0) for k in main_assets}, **nonzero}
        for asset, bal in sorted(show_assets.items()):
            print(f"    {asset:<10} : {bal:.6f}")
        total_unrealised = sum(float(a["unrealizedProfit"]) for a in fut_data["assets"])
        print(f"    UnrealizedPnL : ${total_unrealised:.4f}")

    print("=" * 58 + "\n")


# ── PLACE SPOT ISOLATED MARGIN ORDER ─────────────────────────────
def place_spot_order(symbol, side, qty, cfg, side_effect="MARGIN_BUY"):
    """Returns (ok, fill_price). fill_price = VWAP from actual fills."""
    params = {
        "symbol"        : symbol,
        "side"          : side,
        "type"          : "MARKET",
        "quantity"      : qty,
        "isIsolated"    : "TRUE",
        "sideEffectType": side_effect,
    }
    resp = signed_request("POST", MARGIN_ORDER_URL, params, cfg)
    if "code" in resp:
        print(f"  [!] MARGIN-SPOT {side} FAILED: {resp.get('msg', resp)}")
        return False, 0.0
    # Compute VWAP from fills
    fills = resp.get("fills", [])
    if fills:
        total_qty = sum(float(f["qty"]) for f in fills)
        fill_price = sum(float(f["price"]) * float(f["qty"]) for f in fills) / total_qty
    else:
        fill_price = float(resp.get("price", 0.0)) or float(resp.get("cummulativeQuoteQty", 0.0)) / qty
    if fill_price == 0.0:
        print(f"  [!] MARGIN-SPOT {side}: could not determine fill price (orderId={resp.get('orderId','?')}). Aborting.")
        return False, 0.0
    print(f"  MARGIN-SPOT {side} {qty} {symbol}  filled@{fill_price:.2f}  orderId={resp.get('orderId','?')}")
    return True, fill_price


# ── PLACE FUTURES ORDER ───────────────────────────────────────────
def _get_futures_fill_price(order_id, symbol, cfg):
    """Query a futures order by ID to get the actual avgPrice (handles avgPrice=0 on MARKET orders)."""
    resp = signed_request("GET", FUT_ORDER_URL,
                          {"symbol": symbol, "orderId": order_id}, cfg)
    return float(resp.get("avgPrice", 0.0))


def place_futures_order(symbol, side, qty, cfg):
    """Returns (ok, fill_price). Queries order status if avgPrice=0 on initial response."""
    params = {
        "symbol"     : symbol,
        "side"       : side,
        "type"       : "MARKET",
        "quantity"   : qty,
        "reduceOnly" : "false",
    }
    resp = signed_request("POST", FUT_ORDER_URL, params, cfg)
    if "code" in resp:
        print(f"  [!] FUTURES {side} FAILED: {resp.get('msg', resp)}")
        return False, 0.0
    order_id   = resp.get("orderId")
    fill_price = float(resp.get("avgPrice", 0.0))
    # Binance futures MARKET orders often return avgPrice=0 immediately — re-query
    if fill_price == 0.0 and order_id:
        time.sleep(0.15)  # give exchange 150ms to settle
        fill_price = _get_futures_fill_price(order_id, symbol, cfg)
    if fill_price == 0.0:
        print(f"  [!] FUTURES {side}: could not determine fill price (orderId={order_id}). Aborting.")
        return False, 0.0
    print(f"  FUTURES {side} {qty} {symbol}  filled@{fill_price:.2f}  orderId={order_id}")
    return True, fill_price


# ── CLOSE FUTURES ORDER ───────────────────────────────────────────
def close_futures_order(symbol, side, qty, cfg):
    """Returns (ok, fill_price)."""
    params = {
        "symbol"     : symbol,
        "side"       : side,
        "type"       : "MARKET",
        "quantity"   : qty,
        "reduceOnly" : "true",
    }
    resp = signed_request("POST", FUT_ORDER_URL, params, cfg)
    if "code" in resp:
        print(f"  [!] FUTURES CLOSE {side} FAILED: {resp.get('msg', resp)}")
        return False, 0.0
    fill_price = float(resp.get("avgPrice", 0.0))
    if fill_price == 0.0:
        fill_price = float(resp.get("price", 0.0))
    print(f"  FUTURES CLOSE {side} {qty} {symbol}  filled@{fill_price:.2f}  orderId={resp.get('orderId','?')}")
    return True, fill_price


# ── COMPUTE LIVE SPREAD METRICS ───────────────────────────────────
def compute_spread_metrics(spot_p, fut_p, expiry_dt):
    now   = datetime.datetime.now(datetime.timezone.utc)
    secs  = max((expiry_dt - now).total_seconds(), 60.0)
    dte   = secs / 86400.0

    spread      = fut_p - spot_p
    spread_rate = spread / spot_p
    apr         = spread_rate * 365.0 / dte * 100.0
    return spread, spread_rate, apr, dte


# ── ENTRY SIGNAL (reuses backtest logic verbatim) ─────────────────
def check_entry_signal(spread, apr, dte, spot_p, fut_p, cfg):
    sf       = cfg["spot_fee"]
    ff       = cfg["futures_fee"]
    min_apr  = cfg["min_apr_pct"]
    fee_mult = cfg["fee_safety_mult"]
    min_dte  = cfg["min_dte"]

    sp_entry_on  = cfg["spread_entry_enabled"]
    sp_entry_min = cfg["spread_entry_min_usdt"]
    sp_entry_dte = cfg["spread_entry_min_dte"]

    if dte < min_dte:
        return None, None

    rt_fee = 2.0 * (spot_p * sf + fut_p * ff)          # per-unit, qty-independent

    mode_a = (apr >= min_apr)
    mode_b = (sp_entry_on and abs(spread) >= sp_entry_min and dte >= sp_entry_dte)

    if (mode_a or mode_b) and abs(spread) > rt_fee * fee_mult:
        direction  = "long_spot_short_fut" if spread > 0 else "short_spot_long_fut"
        entry_mode = "APR" if mode_a else "SPREAD"
        return direction, entry_mode

    return None, None


# ── EXIT SIGNAL (reuses backtest logic verbatim) ──────────────────
def check_exit_signal(trade, spread, dte, spot_p, fut_p, bars_held, cfg, expiry_dt):
    sf   = cfg["spot_fee"]
    ff   = cfg["futures_fee"]
    qty  = cfg["quantity"]

    close_before = datetime.timedelta(minutes=cfg["close_before_expiry_mins"])
    now          = datetime.datetime.now(datetime.timezone.utc)
    tte          = expiry_dt - now
    expiry_exit  = tte <= close_before

    if trade["direction"] == "long_spot_short_fut":
        gross = (spot_p - trade["entry_spot"]) * qty + (trade["entry_fut"] - fut_p) * qty
    else:
        gross = (trade["entry_spot"] - spot_p) * qty + (fut_p - trade["entry_fut"]) * qty

    fee_now  = spot_p * qty * sf + fut_p * qty * ff
    live_net = gross - trade["entry_fees"] - fee_now

    if dte >= 30:
        exit_target = abs(trade["entry_spread"]) * (1.0 - cfg["exit_pct_of_entry"])
    else:
        exit_target = cfg["exit_spread_usdt"]

    min_hold = cfg["min_hold_bars"]
    early_exit = (abs(spread) <= exit_target and bars_held >= min_hold and live_net > 0)

    return early_exit or expiry_exit, live_net, "expiry" if expiry_exit else "convergence"


# ── MAIN LOOP ─────────────────────────────────────────────────────
def run_live(cfg):
    print("\n" + "=" * 58)
    print("  SPOT-QUARTERLY FUTURES SPREAD ARB — LIVE TRADER")
    print("  Symbol        : " + cfg["symbol"])
    print("  Quantity      : " + str(cfg["quantity"]) + " BTC")
    print("  Spot Margin   : " + cfg["spot_margin_type"] + "  " + str(cfg["spot_leverage"]) + "x")
    print("  Futures Lev   : " + str(cfg["leverage"]) + "x")
    print("  Scan speed    : " + str(cfg["scan_interval_ms"]) + " ms")
    print("=" * 58)

    # ── 1. Show balances ──────────────────────────────────────────
    display_balances(cfg)

    # ── 2. Discover contract ──────────────────────────────────────
    print("[+] Discovering quarterly contracts ...")
    contracts = get_quarterly_contracts(cfg["symbol"])
    if not contracts:
        print("[!] No quarterly contracts found. Exiting.")
        return
    for idx, c in enumerate(contracts):
        marker = " <-- SELECTED" if idx == cfg["use_contract"] else ""
        print(f"  [{idx}] {c['symbol']}  |  {c['type']}  |  expiry: {c['expiry_dt'].strftime('%Y-%m-%d')}{marker}")

    if cfg["use_contract"] >= len(contracts):
        print("[!] use_contract index out of range.")
        return

    target     = contracts[cfg["use_contract"]]
    fut_symbol = target["symbol"]
    expiry_dt  = target["expiry_dt"]

    print(f"\n[+] Selected: {fut_symbol}  (expires {expiry_dt.strftime('%Y-%m-%d %H:%M UTC')})")

    # ── 3. Set leverage: futures + spot isolated margin ──────────
    set_leverage(fut_symbol, cfg["leverage"], cfg)
    setup_spot_isolated_margin(cfg["symbol"], cfg["spot_leverage"], cfg)

    # ── 4. Fee summary + capital requirements (live prices) ──────
    try:
        _sp  = get_spot_price(cfg["symbol"])
        _fp  = get_fut_price(fut_symbol)
        _qty = cfg["quantity"]
        _sf  = cfg["spot_fee"]
        _ff  = cfg["futures_fee"]

        # ── Fees ──────────────────────────────────────────────────
        _fee_open  = _sp * _qty * _sf + _fp * _qty * _ff
        _fee_close = _sp * _qty * _sf + _fp * _qty * _ff
        _rt_fee    = _fee_open + _fee_close
        _rt_fee_1u = 2.0 * (_sp * _sf + _fp * _ff)   # per-unit, matches backtest gate

        # ── Capital required (margin = notional / leverage) ───────
        _spot_notional = _sp * _qty
        _fut_notional  = _fp * _qty
        _spot_margin   = _spot_notional / cfg["spot_leverage"]    # collateral in spot isolated wallet
        _fut_margin    = _fut_notional  / cfg["leverage"]         # initial margin in futures wallet
        # Add ~10% buffer for price moves / maintenance margin
        _spot_buf = _spot_margin * 1.10
        _fut_buf  = _fut_margin  * 1.10
        _total    = _spot_buf + _fut_buf

        print("\n" + "=" * 58)
        print("  FEE ESTIMATE + CAPITAL REQUIRED  (qty=" + str(_qty) + " BTC)")
        print("=" * 58)
        print(f"  Spot price now         : ${_sp:,.2f}")
        print(f"  Futures price now      : ${_fp:,.2f}")
        print(f"  Notional (spot leg)    : ${_spot_notional:,.2f}  ({_qty} BTC × ${_sp:,.0f})")
        print(f"  Notional (futures leg) : ${_fut_notional:,.2f}  ({_qty} BTC × ${_fp:,.0f})")
        print(f"  Est. round-trip fees   : ${_rt_fee:,.4f}")
        print(f"  Est. spot margin req.  : ${_spot_margin:,.2f} (buffered: ${_spot_buf:,.2f})")
        print(f"  Est. futures margin req.: ${_fut_margin:,.2f} (buffered: ${_fut_buf:,.2f})")
        print(f"  TOTAL CAPITAL REQUIRED : ${_total:,.2f}")
        print("=" * 58 + "\n")

    except Exception as e:
        print(f"[!] Could not fetch initial prices for fee/capital estimate: {e}")
        print("    Check API keys, network, and symbol validity. Exiting.")
        return
    # ── 5. WebSocket setup ──────────────────────────────────────────
    ws_manager = BinanceWebSocketManager(cfg["symbol"], fut_symbol)
    print("\n[+] Connecting to Binance WebSockets for live data ...")
    ws_manager.start()
    
    # Wait for first price tick
    print("    Waiting for first price ticks...")
    while ws_manager.get_spot_price() == 0.0 or ws_manager.get_fut_price() == 0.0:
        time.sleep(0.1)

    # ── 6. Main scan loop ───────────────────────────────────────────
    open_trade       = None
    bars_held        = 0
    session_pnl      = 0.0
    session_trades   = 0
    # Sleep is now ultra low (10ms) since prices update in background threads
    sleep_s          = 0.01

    print("[+] Streaming active. Starting live scan loop. Ctrl+C to stop.\n")
    
    last_print = 0
    print_interval_sec = 5.0  # Configurable console print delay

    try:
        while True:
            spot_p = ws_manager.get_spot_price()
            fut_p  = ws_manager.get_fut_price()
            
            if spot_p == 0.0 or fut_p == 0.0:
                time.sleep(sleep_s)
                continue

            spread, spread_rate, apr, dte = compute_spread_metrics(spot_p, fut_p, expiry_dt)

            now_ts = time.time()
            if now_ts - last_print >= print_interval_sec:
                now_str = datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]
                print(f"[{now_str}]  SPOT={spot_p:.2f}  FUT={fut_p:.2f}  "
                      f"SPREAD={spread:+.2f}  APR={apr:.2f}%  DTE={dte:.1f}d")
                last_print = now_ts

            spread, spread_rate, apr, dte = compute_spread_metrics(spot_p, fut_p, expiry_dt)

            # ── EXIT check ────────────────────────────────────────────
            if open_trade is not None:
                bars_held += 1
                should_exit, live_net, reason = check_exit_signal(
                    open_trade, spread, dte, spot_p, fut_p, bars_held, cfg, expiry_dt
                )

                print(f"  [POSITION]  dir={open_trade['direction']}  "
                      f"entry_spread={open_trade['entry_spread']:+.2f}  "
                      f"live_net=${live_net:.4f}  held={bars_held}bars")

                if should_exit:
                    print(f"\n  >>> EXIT triggered  reason={reason}")
                    qty = cfg["quantity"]
                    sf  = cfg["spot_fee"]
                    ff  = cfg["futures_fee"]

                    if open_trade["direction"] == "long_spot_short_fut":
                        # Sell spot (repay borrowed USDT), Buy futures
                        sp_ok, exit_spot_fill = place_spot_order(cfg["symbol"], "SELL", qty, cfg, side_effect="AUTO_REPAY")
                        ft_ok, exit_fut_fill  = close_futures_order(fut_symbol, "BUY", qty, cfg)
                    else:
                        # Buy spot (borrow USDT if needed), Sell futures
                        sp_ok, exit_spot_fill = place_spot_order(cfg["symbol"], "BUY", qty, cfg, side_effect="MARGIN_BUY")
                        ft_ok, exit_fut_fill  = close_futures_order(fut_symbol, "SELL", qty, cfg)

                    # ── Actual PnL from real fill prices ────────────────────────
                    if sp_ok and ft_ok:
                        if open_trade["direction"] == "long_spot_short_fut":
                            gross = ((exit_spot_fill - open_trade["entry_spot"]) * qty +
                                     (open_trade["entry_fut"]  - exit_fut_fill)  * qty)
                        else:
                            gross = ((open_trade["entry_spot"] - exit_spot_fill) * qty +
                                     (exit_fut_fill - open_trade["entry_fut"])   * qty)
                        exit_fees  = exit_spot_fill * qty * sf + exit_fut_fill * qty * ff
                        actual_net = gross - open_trade["entry_fees"] - exit_fees
                        session_pnl    += actual_net
                        session_trades += 1
                        actual_spread   = exit_fut_fill - exit_spot_fill
                        print(f"  [CLOSED]")
                        print(f"    entry_spot={open_trade['entry_spot']:.2f}  exit_spot={exit_spot_fill:.2f}")
                        print(f"    entry_fut={open_trade['entry_fut']:.2f}   exit_fut={exit_fut_fill:.2f}")
                        print(f"    exit_spread={actual_spread:.2f}  gross=${gross:.4f}")
                        print(f"    entry_fees=${open_trade['entry_fees']:.4f}  exit_fees=${exit_fees:.4f}")
                        print(f"    ACTUAL net_pnl = ${actual_net:.4f}  [session #{session_trades}: ${session_pnl:.4f} total]")
                    else:
                        print(f"  [!] Partial fill on exit — check Binance manually!")
                        print(f"      spot_ok={sp_ok}  fut_ok={ft_ok}")

                    open_trade = None
                    bars_held  = 0
                    print()

            # ── ENTRY check ────────────────────────────────────────────
            elif open_trade is None:
                direction, entry_mode = check_entry_signal(
                    spread, apr, dte, spot_p, fut_p, cfg
                )

                if direction is not None:
                    qty = cfg["quantity"]
                    sf  = cfg["spot_fee"]
                    ff  = cfg["futures_fee"]

                    print(f"\n  >>> ENTRY triggered  dir={direction}  mode={entry_mode}  spread={spread:+.2f}")

                    if direction == "long_spot_short_fut":
                        sp_ok, entry_spot_fill = place_spot_order(cfg["symbol"], "BUY", qty, cfg)
                        ft_ok, entry_fut_fill  = place_futures_order(fut_symbol, "SELL", qty, cfg)
                    else:
                        sp_ok, entry_spot_fill = place_spot_order(cfg["symbol"], "SELL", qty, cfg)
                        ft_ok, entry_fut_fill  = place_futures_order(fut_symbol, "BUY", qty, cfg)

                    if not sp_ok or not ft_ok:
                        print(f"  [!] Entry aborted — order failed (spot={sp_ok} fut={ft_ok})")
                        print(f"      Manual check required on Binance.")
                    else:
                        actual_entry_spread = entry_fut_fill - entry_spot_fill
                        fee_open = entry_spot_fill * qty * sf + entry_fut_fill * qty * ff
                        open_trade = {
                            "direction"   : direction,
                            "entry_mode"  : entry_mode,
                            "entry_spot"  : entry_spot_fill,   # ACTUAL fill price
                            "entry_fut"   : entry_fut_fill,    # ACTUAL fill price
                            "entry_spread": actual_entry_spread,
                            "entry_apr"   : apr,
                            "entry_dte"   : dte,
                            "entry_fees"  : fee_open,
                            "entry_time"  : datetime.datetime.now(datetime.timezone.utc),
                        }
                        bars_held = 0
                        print(f"  [OPEN]  spot_fill={entry_spot_fill:.2f}  fut_fill={entry_fut_fill:.2f}  "
                              f"actual_spread={actual_entry_spread:+.2f}  entry_fees=${fee_open:.4f}\n")

            time.sleep(sleep_s)

    finally:
        ws_manager.stop()
        # Emergency close if position is open when bot stops
        if open_trade is not None:
            print("\n[!] BOT STOPPED WITH OPEN POSITION. FORCING EMERGENCY CLOSE...")
            qty = cfg["quantity"]
            if open_trade["direction"] == "long_spot_short_fut":
                place_spot_order(cfg["symbol"], "SELL", qty, cfg, side_effect="AUTO_REPAY")
                close_futures_order(fut_symbol, "BUY", qty, cfg)
            else:
                place_spot_order(cfg["symbol"], "BUY", qty, cfg, side_effect="MARGIN_BUY")
                close_futures_order(fut_symbol, "SELL", qty, cfg)
            print("[+] Emergency close orders submitted. Check Binance for fills.")

    return session_pnl, session_trades


# ── ENTRY POINT ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    cfg = LIVE_CONFIG

    if cfg["api_key"] == "YOUR_API_KEY":
        print("[!] ERROR: Set your api_key and api_secret in LIVE_CONFIG before running.")
        exit(1)

    _pnl, _trades = 0.0, 0
    try:
        _pnl, _trades = run_live(cfg)
    except KeyboardInterrupt:
        pass
    finally:
        print("\n\n" + "=" * 58)
        print("  SESSION SUMMARY")
        print("=" * 58)
        print(f"  Completed trades  : {_trades}")
        print(f"  Total realized PnL: ${_pnl:.4f}")
        if _trades > 0:
            print(f"  Avg PnL / trade   : ${_pnl / _trades:.4f}")
        print("=" * 58)
        print("[+] Goodbye.")
