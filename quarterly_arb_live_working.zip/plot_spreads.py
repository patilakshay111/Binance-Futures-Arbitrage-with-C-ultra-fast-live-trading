import os
import json
import time
import requests
import datetime
import pandas as pd
import matplotlib.pyplot as plt

CONFIG = {
    "symbol": "ETHUSDT",
    "backtest_days": 0.5,
    "use_contract": 0
}



SPOT_URL    = "https://api.binance.com/api/v3/klines"
FUTURES_URL = "https://fapi.binance.com/fapi/v1/klines"
EXCH_URL    = "https://fapi.binance.com/fapi/v1/exchangeInfo"

def get_quarterly_contracts(base_symbol):
    r = requests.get(EXCH_URL, timeout=15)
    contracts = []
    for s in r.json().get("symbols", []):
        name  = s["baseAsset"] + s["quoteAsset"]
        ctype = s["contractType"]
        if (name == base_symbol and
                ctype in ("CURRENT_QUARTER", "NEXT_QUARTER") and
                s["status"] == "TRADING"):
            exp_ms = int(s["deliveryDate"])
            exp_dt = datetime.datetime.fromtimestamp(
                exp_ms / 1000, tz=datetime.timezone.utc)
            contracts.append({
                "symbol"    : s["symbol"],
                "type"      : ctype,
                "expiry_ms" : exp_ms,
                "expiry_dt" : exp_dt,
            })
    return sorted(contracts, key=lambda x: x["expiry_ms"])

def fetch_klines(url, symbol, start_ms, end_ms):
    cols = ["open_time", "open", "high", "low", "close", "volume",
            "close_time", "quote_vol", "trades",
            "taker_base", "taker_quote", "ignore"]
    frames = []
    t = start_ms
    session = requests.Session()
    while t < end_ms:
        params = dict(symbol=symbol, interval="1m",
                      startTime=int(t), endTime=int(end_ms), limit=1000)
        try:
            r = session.get(url, params=params, timeout=20)
            data = r.json()
        except requests.exceptions.RequestException as e:
            print(f"Error fetching data: {e}")
            break
        
        if not data or isinstance(data, dict):
            break
        df = pd.DataFrame(data, columns=cols)
        df["open_time"] = df["open_time"].astype(int)
        df["close"]     = df["close"].astype(float)
        frames.append(df)
        t = df["open_time"].iloc[-1] + 60000
        if len(data) < 1000:
            break
        time.sleep(0.05)
    if not frames:
        return pd.DataFrame()
    out = pd.concat(frames, ignore_index=True)
    out["ts"] = pd.to_datetime(out["open_time"], unit="ms", utc=True)
    out = out.set_index("ts").sort_index()
    out = out[~out.index.duplicated(keep="first")]
    return out[["close"]]

def main():
    cfg = CONFIG
    print(f"[*] Configuration: {cfg}")
    print(f"[*] Discovering quarterly contracts for {cfg['symbol']}...")
    contracts = get_quarterly_contracts(cfg["symbol"])
    if not contracts:
        print("[!] No quarterly contracts found.")
        return

    print("Available contracts:")
    for idx, c in enumerate(contracts):
        marker = " <-- SELECTED" if idx == cfg["use_contract"] else ""
        print(f"  [{idx}] {c['symbol']} | {c['type']} | expires: {c['expiry_dt'].strftime('%Y-%m-%d')}{marker}")
    
    if cfg["use_contract"] >= len(contracts):
        print(f"[!] use_contract index out of range. Using 0 instead.")
        cfg["use_contract"] = 1
        
    target = contracts[cfg["use_contract"]]
    
    now_ms   = int(datetime.datetime.now(datetime.timezone.utc).timestamp() * 1000)
    start_ms = now_ms - cfg["backtest_days"] * 24 * 3600 * 1000

    print(f"[*] Fetching SPOT {cfg['symbol']}...")
    spot = fetch_klines(SPOT_URL, cfg["symbol"], start_ms, now_ms)
    print(f"    Fetched {len(spot)} min candles")

    print(f"[*] Fetching FUTURES {target['symbol']}...")
    fut = fetch_klines(FUTURES_URL, target["symbol"], start_ms, now_ms)
    print(f"    Fetched {len(fut)} min candles")

    if spot.empty or fut.empty:
        print("[!] Could not fetch data.")
        return
        
    df = pd.DataFrame({"spot": spot["close"], "futures": fut["close"]}).dropna()
    if df.empty:
        print("[!] No overlapping data to plot.")
        return
        
    df["spread"] = df["futures"] - df["spot"]
    
    print(f"[*] Plotting {len(df)} data points...")
    plt.figure(figsize=(12, 6))
    plt.plot(df.index, df["spread"], label=f"Spread ({target['symbol']} - {cfg['symbol']})", color="blue")
    plt.title(f"Spot vs Quarterly Futures Spread: {cfg['symbol']} | Contract: {target['type']}")
    plt.xlabel("Date")
    plt.ylabel("Spread (USDT)")
    plt.grid(True, linestyle="--", alpha=0.7)
    plt.legend()
    plt.tight_layout()
    
    save_path = f"spread_plot_{target['symbol']}.png"
    plt.savefig(save_path)
    print(f"[*] Plot saved to {save_path}")
    
    try:
        plt.show()
    except Exception as e:
        print(f"[*] Could not display plot window: {e}")

if __name__ == "__main__":
    main()
