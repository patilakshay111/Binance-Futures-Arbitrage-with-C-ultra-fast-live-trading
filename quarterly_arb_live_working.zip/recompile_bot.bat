@echo off
echo Setting MSYS2 Library Paths...
set PATH=C:\msys64\mingw64\bin;C:\msys64\usr\bin;%PATH%
set "CMAKE_EXE=C:\msys64\mingw64\bin\cmake.exe"
set "SOURCE_DIR=%~dp0."
set "BUILD_DIR=%~dp0build"

echo Recompiling C++ Trading Bot...
if not exist "%BUILD_DIR%" mkdir "%BUILD_DIR%"

REM Clean stale CMake cache when project path changes
if exist "%BUILD_DIR%\CMakeCache.txt" del /f /q "%BUILD_DIR%\CMakeCache.txt"
if exist "%BUILD_DIR%\CMakeFiles" rmdir /s /q "%BUILD_DIR%\CMakeFiles"

"%CMAKE_EXE%" -S "%SOURCE_DIR%" -B "%BUILD_DIR%" -G"MinGW Makefiles"
if %errorlevel% neq 0 (
    echo.
    echo CMAKE CONFIGURATION FAILED! Check the errors above.
    pause
    exit /b %errorlevel%
)

cd /d "%BUILD_DIR%"
mingw32-make

if %errorlevel% neq 0 (
    echo.
    echo COMPILATION FAILED! Check the errors above.
    pause
    exit /b %errorlevel%
)

echo.
echo Compilation Successful!
pause
