
# =================================================================
#  SPOT-QUARTERLY FUTURES SPREAD ARBITRAGE BACKTESTER  v4
#  Fixes: contract selector, dual entry mode, DTE-aware thresholds
#  Run: python quarterly_arb.py
# =================================================================
import requests
import time
import datetime
import pandas as pd
import numpy as np

# ── CONFIG ────────────────────────────────────────────────────────
CONFIG = {
    "symbol"                   : "BTCUSDT",
    "quantity"                 : 1.0,
    "backtest_days"            : 90,
    # 0 = nearest/current quarter  |  1 = next quarter
    "use_contract"             : 0,
    # BNB-discounted taker fees
    "spot_fee"                 : 0.0008,    # 0.075%
    "futures_fee"              : 0.0005,     # 0.045%
    # ── ENTRY MODE A: APR-based (works near expiry, DTE < 30) ──
    "min_apr_pct"              : 2.0,        # 3% APR minimum
    # ── ENTRY MODE B: Spread-based (works early in contract, DTE >= 30) ──
    "spread_entry_enabled"     : True,
    "spread_entry_min_usdt"    : 8.0,      # enter when spread >= $300
    "spread_entry_min_dte"     : 1.0,         # only when DTE >= 30 days
    # ── SHARED ENTRY GATE ──
    "fee_safety_mult"          : 2.2,        # spread must be 1.2x rt_fee (~$192)
    # ── EXIT ──
    # For early contract (DTE>=30): exit when spread drops by exit_pct_of_entry
    # e.g. 0.15 = exit when spread compresses 15% from entry value
    "exit_pct_of_entry"        : 0.20,       # exit when spread <= 80% of entry spread
    # For near-expiry (DTE<30): use fixed USDT target
    "exit_spread_usdt"         : -3.0,
    "min_hold_bars"            : 0,        # min 2h hold (spreads move slowly early)
    "cooldown_bars"            : 0,        # 8h cooldown after exit
    "close_before_expiry_mins" : 120,
    "min_dte"                  : 1.0,
}

SPOT_URL    = "https://api.binance.com/api/v3/klines"
FUTURES_URL = "https://fapi.binance.com/fapi/v1/klines"
EXCH_URL    = "https://fapi.binance.com/fapi/v1/exchangeInfo"


# ── DISCOVER QUARTERLY CONTRACTS ─────────────────────────────────
def get_quarterly_contracts(base_symbol):
    r = requests.get(EXCH_URL, timeout=15)
    contracts = []
    for s in r.json().get("symbols", []):
        name  = s["baseAsset"] + s["quoteAsset"]
        ctype = s["contractType"]
        if (name == base_symbol and
                ctype in ("CURRENT_QUARTER", "NEXT_QUARTER") and
                s["status"] == "TRADING"):
            exp_ms = int(s["deliveryDate"])
            exp_dt = datetime.datetime.fromtimestamp(
                exp_ms / 1000, tz=datetime.timezone.utc)
            contracts.append({
                "symbol"    : s["symbol"],
                "type"      : ctype,
                "expiry_ms" : exp_ms,
                "expiry_dt" : exp_dt,
            })
    return sorted(contracts, key=lambda x: x["expiry_ms"])


# ── FETCH KLINES ──────────────────────────────────────────────────
def fetch_klines(url, symbol, start_ms, end_ms):
    cols = ["open_time", "open", "high", "low", "close", "volume",
            "close_time", "quote_vol", "trades",
            "taker_base", "taker_quote", "ignore"]
    frames = []
    t = start_ms
    while t < end_ms:
        params = dict(symbol=symbol, interval="1m",
                      startTime=t, endTime=end_ms, limit=1000)
        r    = requests.get(url, params=params, timeout=20)
        data = r.json()
        if not data or isinstance(data, dict):
            break
        df = pd.DataFrame(data, columns=cols)
        df["open_time"] = df["open_time"].astype(int)
        df["close"]     = df["close"].astype(float)
        frames.append(df)
        t = int(df["open_time"].iloc[-1]) + 60000
        if len(data) < 1000:
            break
        time.sleep(0.15)
    if not frames:
        return pd.DataFrame()
    out = pd.concat(frames, ignore_index=True)
    out["ts"] = pd.to_datetime(out["open_time"], unit="ms", utc=True)
    out = out.set_index("ts").sort_index()
    out = out[~out.index.duplicated(keep="first")]
    return out[["close"]]


# ── LOAD & MERGE ──────────────────────────────────────────────────
def load_data(cfg, fut_symbol, expiry_dt):
    now_ms   = int(datetime.datetime.now(datetime.timezone.utc).timestamp() * 1000)
    start_ms = now_ms - cfg["backtest_days"] * 24 * 3600 * 1000

    print("[+] Fetching SPOT " + cfg["symbol"] + " ...")
    spot = fetch_klines(SPOT_URL, cfg["symbol"], start_ms, now_ms)
    print("    " + str(len(spot)) + " rows fetched")

    print("[+] Fetching FUTURES " + fut_symbol + " ...")
    fut = fetch_klines(FUTURES_URL, fut_symbol, start_ms, now_ms)
    print("    " + str(len(fut)) + " rows fetched")

    df = pd.DataFrame({"spot": spot["close"], "futures": fut["close"]}).dropna()

    # -- DTE calc: robust Series conversion
    td_index = expiry_dt - df.index
    secs     = pd.Series(td_index.total_seconds().values, index=df.index)
    df["days_to_exp"]  = (secs / 86400).clip(lower=1.0/1440)
    df["spread"]       = df["futures"] - df["spot"]
    df["spread_rate"]  = df["spread"]  / df["spot"]
    df["apr"]          = df["spread_rate"].abs() * 365 / df["days_to_exp"] * 100

    actual_rows = len(df)
    print("[+] Aligned rows (after dropna) : " + str(actual_rows))
    print("    NOTE: futures data only available from contract listing date")

    if actual_rows == 0:
        print("[!] No aligned data. Contract may not have started yet.")
        return df

    date_range = str(df.index[0].date()) + " to " + str(df.index[-1].date())
    print("    Data range : " + date_range)

    print("")
    print("[+] Spread Diagnostics:")
    print("    mean    = $" + str(round(df["spread"].mean(), 2)))
    print("    std     = $" + str(round(df["spread"].std(), 2)))
    print("    min     = $" + str(round(df["spread"].min(), 2)))
    print("    max     = $" + str(round(df["spread"].max(), 2)))
    print("    APR mean  = " + str(round(df["apr"].mean(), 2)) + "%")
    print("    APR max   = " + str(round(df["apr"].max(), 2)) + "%")
    print("    APR>=5%   : " + str(int((df["apr"] >= 5).sum())) + " bars")
    apr_t = cfg["min_apr_pct"]
    print("    APR>=" + str(apr_t) + "%  : " + str(int((df["apr"] >= apr_t).sum())) + " bars")
    sp_t  = cfg["spread_entry_min_usdt"]
    print("    |sp|>$" + str(sp_t) + " : " + str(int((df["spread"].abs() > sp_t).sum())) + " bars")
    print("    DTE>=30   : " + str(int((df["days_to_exp"] >= 30).sum())) + " bars")
    return df


# ── BACKTEST ──────────────────────────────────────────────────────
def backtest(df, cfg, expiry_dt):
    if df.empty:
        return pd.DataFrame()

    qty          = cfg["quantity"]
    sf           = cfg["spot_fee"]
    ff           = cfg["futures_fee"]
    min_apr      = cfg["min_apr_pct"]
    fee_mult     = cfg["fee_safety_mult"]
    exit_sp      = cfg["exit_spread_usdt"]
    min_hold     = cfg["min_hold_bars"]
    cooldown     = cfg["cooldown_bars"]
    min_dte      = cfg["min_dte"]
    close_before = datetime.timedelta(minutes=cfg["close_before_expiry_mins"])

    sp_entry_on  = cfg["spread_entry_enabled"]
    sp_entry_min = cfg["spread_entry_min_usdt"]
    sp_entry_dte = cfg["spread_entry_min_dte"]

    trades        = []
    in_trade      = False
    cooldown_left = 0
    entry_idx     = 0
    entry_time    = None
    entry_spot    = 0.0
    entry_fut     = 0.0
    entry_spread  = 0.0
    entry_apr     = 0.0
    entry_dte     = 0.0
    entry_fees    = 0.0
    entry_mode    = ""
    trade_dir     = ""

    rows = list(df.iterrows())

    for i, (ts, row) in enumerate(rows):
        spread = float(row["spread"])
        apr    = float(row["apr"])
        dte    = float(row["days_to_exp"])
        spot_p = float(row["spot"])
        fut_p  = float(row["futures"])

        if cooldown_left > 0:
            cooldown_left -= 1

        # ── EXIT ──────────────────────────────────────────────
        if in_trade:
            bars_held   = i - entry_idx
            tte         = expiry_dt - ts
            expiry_exit = tte <= close_before

            if trade_dir == "long_spot_short_fut":
                gross = (spot_p - entry_spot) * qty + (entry_fut - fut_p) * qty
            else:
                gross = (entry_spot - spot_p) * qty + (fut_p - entry_fut) * qty

            fee_now  = spot_p * qty * sf + fut_p * qty * ff
            live_net = gross - entry_fees - fee_now

            # Exit target: pct-based when DTE>=30, fixed USDT when DTE<30
            if dte >= 30:
                exit_target = abs(entry_spread) * (1.0 - cfg["exit_pct_of_entry"])
            else:
                exit_target = exit_sp

            early_exit = (abs(spread) <= exit_target and
                          bars_held   >= min_hold         and
                          live_net    >  0)

            if early_exit or expiry_exit:
                total_fees = entry_fees + fee_now
                reason     = "expiry" if expiry_exit else "convergence"
                trades.append({
                    "open_time"         : entry_time,
                    "exit_time"         : ts,
                    "direction"         : trade_dir,
                    "entry_mode"        : entry_mode,
                    "entry_spot"        : round(entry_spot, 2),
                    "entry_futures"     : round(entry_fut, 2),
                    "exit_spot"         : round(spot_p, 2),
                    "exit_futures"      : round(fut_p, 2),
                    "entry_spread"      : round(entry_spread, 2),
                    "exit_spread"       : round(spread, 2),
                    "entry_apr_pct"     : round(entry_apr, 4),
                    "days_to_exp_entry" : round(entry_dte, 2),
                    "hold_minutes"      : bars_held,
                    "exit_reason"       : reason,
                    "gross_pnl_usdt"    : round(gross, 4),
                    "total_fees_usdt"   : round(total_fees, 4),
                    "net_pnl_usdt"      : round(live_net, 4),
                })
                in_trade      = False
                cooldown_left = cooldown

        # ── ENTRY ─────────────────────────────────────────────
        if not in_trade and cooldown_left == 0 and dte >= min_dte:
            rt_fee = 2.0 * (spot_p * 1.0 * sf + fut_p * 1.0 * ff)  # per-unit, qty-independent

            mode_a = (apr >= min_apr)
            mode_b = (sp_entry_on and
                      abs(spread) >= sp_entry_min and
                      dte >= sp_entry_dte)

            if (mode_a or mode_b) and abs(spread) > rt_fee * fee_mult:  # spread vs per-unit fee
                in_trade     = True
                entry_idx    = i
                entry_time   = ts
                entry_spot   = spot_p
                entry_fut    = fut_p
                entry_spread = spread
                entry_apr    = apr
                entry_dte    = dte
                entry_fees   = spot_p * qty * sf + fut_p * qty * ff
                entry_mode   = "APR" if mode_a else "SPREAD"
                trade_dir    = "long_spot_short_fut" if spread > 0 else "short_spot_long_fut"

    return pd.DataFrame(trades)


# ── STATS ─────────────────────────────────────────────────────────
def print_stats(tdf, cfg, fut_symbol, expiry_dt):
    sep = "=" * 58
    print("")
    print(sep)
    print("  QUARTERLY SPREAD ARB | " + cfg["symbol"] + " vs " + fut_symbol)
    print("  Expiry  : " + expiry_dt.strftime("%Y-%m-%d %H:%M UTC"))
    print("  Contract: " + ("NEXT QUARTER" if cfg["use_contract"] == 1 else "CURRENT QUARTER"))
    print(sep)

    if tdf.empty:
        print("  [!] No trades found. Suggestions:")
        print("  - Lower min_apr_pct (current: " + str(cfg["min_apr_pct"]) + "%)")
        print("  - Lower spread_entry_min_usdt (current: $" + str(cfg["spread_entry_min_usdt"]) + ")")
        print("  - Enable spread_entry_enabled = True")
        print("  - Increase backtest_days")
        return

    n         = len(tdf)
    wins      = int((tdf["net_pnl_usdt"] > 0).sum())
    losses    = n - wins
    win_rate  = wins / n * 100
    total_net = tdf["net_pnl_usdt"].sum()
    avg_net   = tdf["net_pnl_usdt"].mean()
    best      = tdf["net_pnl_usdt"].max()
    worst     = tdf["net_pnl_usdt"].min()
    tot_fees  = tdf["total_fees_usdt"].sum()
    avg_hold  = tdf["hold_minutes"].mean()
    max_hold  = tdf["hold_minutes"].max()
    avg_eapr  = tdf["entry_apr_pct"].mean()
    avg_ensp  = tdf["entry_spread"].abs().mean()
    avg_exsp  = tdf["exit_spread"].abs().mean()
    avg_dte   = tdf["days_to_exp_entry"].mean()
    conv      = int((tdf["exit_reason"] == "convergence").sum())
    expr      = int((tdf["exit_reason"] == "expiry").sum())
    apr_mode  = int((tdf["entry_mode"] == "APR").sum())
    sp_mode   = int((tdf["entry_mode"] == "SPREAD").sum())

    equity  = tdf["net_pnl_usdt"].cumsum()
    max_dd  = float((equity - equity.cummax()).min())
    pf_num  = float(tdf.loc[tdf["net_pnl_usdt"] > 0,  "net_pnl_usdt"].sum())
    pf_den  = float(abs(tdf.loc[tdf["net_pnl_usdt"] <= 0, "net_pnl_usdt"].sum()))
    pf      = pf_num / pf_den if pf_den > 0 else float("inf")

    tdf["exit_date"] = pd.to_datetime(tdf["exit_time"]).dt.date
    daily  = tdf.groupby("exit_date")["net_pnl_usdt"].sum()
    sharpe = float(daily.mean() / daily.std() * (365 ** 0.5)
                   if len(daily) > 1 and daily.std() > 0 else float("nan"))

    def r(label, val):
        print("  " + str(label).ljust(34) + ": " + str(val))

    r("Quantity",              str(cfg["quantity"]) + " BTC")
    r("Spot Fee",              str(cfg["spot_fee"] * 100) + "%")
    r("Futures Fee",           str(cfg["futures_fee"] * 100) + "%")
    r("Entry Mode A (APR>=)",  str(cfg["min_apr_pct"]) + "%")
    r("Entry Mode B (|sp|>=)", "$" + str(cfg["spread_entry_min_usdt"]) + " when DTE>=" + str(cfg["spread_entry_min_dte"]) + "d")
    r("Fee Safety Mult",       str(cfg["fee_safety_mult"]) + "x rt_fee")
    r("Exit Spread Target",    "$" + str(cfg["exit_spread_usdt"]))
    r("Min Hold",              str(cfg["min_hold_bars"]) + " min")
    r("Cooldown After Exit",   str(cfg["cooldown_bars"]) + " min")
    print(sep)
    r("Total Trades",          str(n))
    r("Win Rate",              str(round(win_rate, 1)) + "%  (" + str(wins) + "W / " + str(losses) + "L)")
    r("Profit Factor",         str(round(pf, 2)))
    r("Sharpe (annualized)",   str(round(sharpe, 2)))
    print(sep)
    r("Total Net PnL",         "$" + str(round(total_net, 2)))
    r("Avg Net PnL / trade",   "$" + str(round(avg_net, 2)))
    r("Best Trade",            "$" + str(round(best, 2)))
    r("Worst Trade",           "$" + str(round(worst, 2)))
    r("Max Drawdown",          "$" + str(round(max_dd, 2)))
    print(sep)
    r("Total Fees Paid",       "$" + str(round(tot_fees, 2)))
    r("Avg Entry APR",         str(round(avg_eapr, 2)) + "%")
    r("Avg Entry |Spread|",    "$" + str(round(avg_ensp, 2)))
    r("Avg Exit  |Spread|",    "$" + str(round(avg_exsp, 2)))
    r("Avg DTE at Entry",      str(round(avg_dte, 1)) + " days")
    print(sep)
    r("Avg Hold (minutes)",    str(round(avg_hold, 1)))
    r("Max Hold (minutes)",    str(max_hold))
    r("Convergence Exits",     str(conv))
    r("Expiry Exits",          str(expr))
    r("APR-mode entries",      str(apr_mode))
    r("Spread-mode entries",   str(sp_mode))
    print(sep)
    for d, c in tdf["direction"].value_counts().items():
        r(str(d), str(c))
    print(sep)

    print("")
    print("  SAMPLE TRADES (first 20):")
    show = ["open_time","exit_time","entry_mode","entry_spread","exit_spread","entry_apr_pct","days_to_exp_entry","hold_minutes","net_pnl_usdt","exit_reason"]
    print(tdf[show].head(5).to_string(index=False))


# ── MAIN ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    cfg = CONFIG

    print("[+] Discovering quarterly contracts for " + cfg["symbol"] + " ...")
    contracts = get_quarterly_contracts(cfg["symbol"])
    if not contracts:
        print("[!] No quarterly contracts found.")
        exit(1)

    print("")
    for idx, c in enumerate(contracts):
        marker = " <-- SELECTED" if idx == cfg["use_contract"] else ""
        print("  [" + str(idx) + "] " + c["symbol"] +
              "  |  " + c["type"] +
              "  |  expiry: " + c["expiry_dt"].strftime("%Y-%m-%d") + marker)

    if cfg["use_contract"] >= len(contracts):
        print("[!] use_contract index out of range. Max index: " + str(len(contracts)-1))
        exit(1)

    target = contracts[cfg["use_contract"]]
    print("")
    print("[+] Selected : " + target["symbol"] +
          "  (expires " + target["expiry_dt"].strftime("%Y-%m-%d") + ")")

    df = load_data(cfg, target["symbol"], target["expiry_dt"])

    if df.empty:
        print("[!] No data to backtest.")
        exit(1)

    print("")
    print("[+] Running backtest ...")
    trades = backtest(df, cfg, target["expiry_dt"])

    print_stats(trades, cfg, target["symbol"], target["expiry_dt"])

    if not trades.empty:
        fname = ("arb_trades_" + target["symbol"] +
                 "_" + str(cfg["backtest_days"]) + "d.csv")
        trades.to_csv(fname, index=False)
        print("")
        print("[+] CSV saved -> " + fname)
    else:
        print("[!] No CSV generated.")
